# Research Continuation Handoff: DMT-native orbital / timing / relativistic-correlation study

## What this package is
This package is a continuation handoff for another ChatGPT conversation to keep iterating on a DMT-native simulation program. It contains:

- the uploaded Python equation files used as the simulation/code spine
- the DMT markdown source files used as the theory/operator reference
- the confined-photon v5 / hybrid species-term files used for the later effective-constant bridge
- the diagnostic artifacts produced during the current exploration
- a continuation prompt for the next chat
- this summary of the math, logic, protocol, and current conclusions

This is a **research package**, not a validated physical theory package. Most simulation results here are toy / analogue results used to isolate operator roles and derive timing/support equations.

---

## Core research question
We are trying to determine which terms are actually responsible for stable orbital-band emergence in a DMT-native 9D conservation simulation, and to derive those terms from **effective constants** and **relativistic correlation**, not from arbitrary scaling factors.

The immediate target system has been a **lithium-targeted absolute-zero diagnostic simulation** because it simplifies the timing/support problem enough to expose the relevant effective quantities.

The longer-term goal is to:
1. build a DMT-native simulation that forms stable inner/outer orbital support bands honestly
2. derive the timing of those bands from effective constants and Doppler-effective counterparts
3. expose the pairwise effective channels so `Rel_ij(t)` can be solved canonically, not guessed
4. only then reintroduce more speculative temporal-coupling / post-confinement recurrence structures

---

## Hard constraints used in the current work
These were treated as active research constraints in the current chat and should be preserved unless the next chat finds a clear simulation-based reason to change them.

1. **Effective constants are derived, never arbitrary.**
   The simulation should use the uploaded `constants_eq.py` / related files to derive effective values through relativistic correlation and stochastic dispersion, not hand-tuned constants.

2. **Identity-preserving vs environment-responsive split must be preserved.**
   The Hamiltonian / operator spine is:
   - freeze identity-preserving structure
   - let environment-responsive terms deform through effective-constant dressing and relative correlation

3. **The simulation should stay photon-native unless proven otherwise.**
   Species-like regimes should be treated as emergent support basins / attractor classes, not as separate ontologies with separate force laws.

4. **Orbitals must be explained through support geometry first.**
   The current work strongly suggests the shell/orbital problem is a radial-support-mapping problem before it is a temporal-coupling problem.

5. **Use known math / operator language where possible.**
   Borrow from QFT only narrowly: mode overlap, exchange-mediated coupling, occupancy-style bookkeeping. Do not pretend the toy lattice is full QFT.

6. **Do not save speculative mechanisms to memory until simulation supports them.**
   This was explicitly requested.

---

## Source files in this package
### Theory / operator reference
- `DMT Publication .md`
- `Dimensional Modularity Theory (1).md`
- `GenesisSubstrate_eq.md`
- `confined_photon_delta_species_terms.md`
- `confined_photon_delta_species_terms_v5_unified.md`

### Python code spine
- `constants_eq.py`
- `hamiltonian_eq.py`
- `lattice9d_eq.py`
- `lorenz_eq.py`
- `measurement_eq.py`
- `pulse_eq.py`
- `qubit_eq.py`
- `schrodinger_eq.py`
- `sim_core.py`
- `state_eq.py`
- `stochastic_eq.py`
- `utils.py`

### Diagnostic artifacts generated in this chat
- `lithium_abszero_peak_events.json`
- `lithium_abszero_peak_summary.csv`
- `lithium_abszero_effective_exposure_events.csv`
- `lithium_abszero_effective_exposure_summary.csv`
- `lithium_abszero_timinglaw_pair_channels.csv`
- `lithium_abszero_timinglaw_replay_history.csv`
- `lithium_abszero_timinglaw_replay_summary.csv`

---

## Dimensional role split used for the DMT-native baseline
From the uploaded DMT publication markdown, the working 9D role split used in the baseline runs was:

- DOF 1-3: spatial
- DOF 4: temporal
- DOF 5: coherence
- DOF 6: flux
- DOF 7: phantom
- DOF 8: aether
- DOF 9: nexus

In the most successful reset runs, this was treated as a **role grammar**, not as a pretext to invent extra arbitrary couplings.

---

## Effective-constant spine actually used
From the uploaded files and the hybrid/v5 bridge, the current work treated these as the key channels:

- `k_eff = k_ref * Rel * Disp`
- `omega_c_eff = M_eff * c_eff^2 / hbar_eff`
- `Xret_i = sum_j absorbed_exchange_ij`
- `Sigma_i = K_eff_i * C_i * R_i * O_orb_i * Rel_i * Tflux_i`
- reduced observable form: `Sigma_eff = K_eff * C_eff * R_eff * Tflux_eff`

Normalized temporal-flux law used in the hybrid patch:

- `Tflux_i = 1 + alpha_tf_i * log(1 + omega_c_eff_i / omega_ref_i) * K_eff_i * Xret_i`
- pairwise form: `Tflux_ij = 1 + alpha_tfp_ij * log(1 + sqrt(omega_c_eff_i * omega_c_eff_j) / omega_ref_ij) * absorbed_exchange_ij`

Pairwise relative-correlation closure used as the honest target, but not fully solvable without pair logs:

- `Rel_ij = sqrt( G_ij * (1 + Tself_eff_i + Tself_eff_j) / (O_ij * R_ij * Tpair_base_ij * Cgate_ij * Tflux_ij) )`

The local reduced anchor at the calibrated confined-photon basin came out as:

- `Rel_i(calibrated basin) = 1.0000`

because

- `Rel_i = Sigma_eff / (K_eff * C_eff * R_eff * O_orb * Tflux_eff)`
- with `O_orb = 1` in the reduced calibrated basis

---

## What the simulations showed, in chronological logic
### 1. Publication-only DMT 9D conservation baseline
A stripped DMT-native lithium-targeted baseline formed **one dominant radial basin**, not multi-shell orbital structure.

Interpretation:
- the DMT-publication grammar is enough to create a stable conserved basin
- it is **not** enough by itself to produce multi-band orbital structure

### 2. Ablation sweep on added probe terms
Added terms were tested one by one and in combinations:
- null-style light handling
- post-confinement recurrence
- 4->5 bleed
- retained-exchange support
- emergent temporal coupling
- QFT-like mode support
- core-derived binding-spectrum support

Result:
- the **core-derived binding-spectrum term** was the one term that consistently created a stable basin
- removing it from the full stack killed the basin
- keeping it while removing most other terms preserved the basin

Conclusion:
- the shell problem is primarily a **radial support mapping / binding-spectrum extraction** problem
- temporal coupling was not the culprit at this stage

### 3. Native radial support decomposition + forced-orbital control
A DMT-native ablation of the radial support mapper and a separate forced-orbital control showed:
- curvature matters most for creating the inner support landscape
- aether and coherence stabilize secondary / outer support
- flux acts mostly as a correction, not the main shell-maker
- temporal ideas are downstream, not primary shell-makers in this reset pass

### 4. Forced-orbital inverse fit
Back-calculating from forced orbitals gave a recovered mapper that reproduced **two stable native bands**, but at `r = 4` and `r = 8` instead of the forced `r = 2` and `r = 6`.

Meaning:
- the recovered mapper had the right qualitative structure (two bands)
- but it lacked the correct inner anchoring / placement term

### 5. Absolute-zero lithium diagnostic
A lithium-targeted absolute-zero diagnostic run was used to expose effective constants at first persistent band appearance.

This simplified the problem because:
- `Tflux_eff` and `Tflux_ij` froze near `1`
- the shell-placement signal became dominated by the radial support context and the effective / Doppler-effective traces

This exposed local appearance-time values for:
- `Rel_i_required`
- `relativistic_corr_eff`
- `scale_eff`
- `scale_eff_doppler`
- `c_eff`, `h_eff`
- `c_eff_doppler`, `h_eff_doppler`
- `K_eff`, `C_eff`, `R_eff`, `omega_eff`, `Xret_eff`, `Sigma_eff`
- curvature, aether, coherence, flux

### 6. Timing law derivation from effective/Doppler-effective traces
This was the first true local timing calculation, not just a summary of values.

The timing law extracted from the absolute-zero lithium exposures was:

`t_appear = 14.5729166667 + 1808.22336112*(omega_eff - 0.9957121838) - 275.99151246*(R_eff - 0.4425915037) + 1367.81476721*(C_eff - 0.3855790654) - 135161.28797655*(scale_eff_doppler - 1.0156430049)`

This reproduced the event timing with:
- `R^2 = 0.99134`
- mean absolute error about `0.858` steps

It predicted the main bands correctly:
- `r = 2`: ~5 steps
- `r = 3`: ~5 steps
- `r = 5`: ~17-18 steps
- `r = 6`: ~31 steps

This is the current working appearance-time calculator.

### 7. Pairwise effective channel exposure
Using the timing law replay, pairwise effective channels were logged at band activation.

Representative values from the replay:
- inner pair `2–3`: `Rel_ij = 0.91533`, `Tpair_base_ij = 1.02161`, `Cgate_ij = 0.42695`, `Tflux_ij = 1.00011549`, `G_ij = 0.08457`
- outer pair `5–6`: `Rel_ij = 0.67870`, `Tpair_base_ij = 1.04417`, `Cgate_ij = 0.34318`, `Tflux_ij = 1.00000033`, `G_ij = 0.01777`

Interpretation:
- the timing side is now calculable from effective constants
- the remaining issue is weak outer-band pair support relative to the inner band

---

## Current best numerical facts
### Calibrated confined-photon reduced basin
- `Rel_i(calibrated basin) = 1.0000`
- `rho_eff = 1.69282633275`
- `omega_c_eff = 2.0795`
- `Xret_eff = 0.00475`
- `Tflux_eff = 1.009877625`
- `Sigma_eff = 0.8220954250805624`

### Absolute-zero lithium local appearance values
#### Inner band (`r = 2`)
- appearance step mean: `5.0`
- `Rel_i_calc`: `0.9484488059413904`
- `relativistic_corr_eff`: `0.997401178611188`
- `scale_eff_doppler`: `1.0097083040698238`
- `K_eff`: `1.0204134246436225`
- `C_eff`: `0.4528496706784569`
- `R_eff`: `0.6`
- `omega_eff`: `0.52`
- `Xret_eff`: `9.9318679432738e-4`
- `Sigma_eff`: `0.26294950801064737`

#### Outer band (`r = 6`)
- appearance step mean: `30.875`
- `Rel_i_calc`: `0.693561558023094`
- `relativistic_corr_eff`: `0.999822247149125`
- `scale_eff_doppler`: `1.0215930682787782`
- `K_eff`: `1.0032913015364382`
- `C_eff`: `0.3295289092423035`
- `R_eff`: `0.3101842964141107`
- `omega_eff`: `1.4716898260003575`
- `Xret_eff`: `1.162338607844842e-6`
- `Sigma_eff`: `0.09228785028803077`

---

## The local timing formula currently in play
This is the current best local timing law derived from effective quantities and their Doppler-effective counterparts:

```text
 t_appear =
 14.5729166667
 + 1808.22336112 * (omega_eff - 0.9957121838)
 - 275.99151246 * (R_eff - 0.4425915037)
 + 1367.81476721 * (C_eff - 0.3855790654)
 - 135161.28797655 * (scale_eff_doppler - 1.0156430049)
```

This is not a final physical law. It is the best current simulation-level calculation for **when** radial support bands appear in the absolute-zero lithium diagnostic.

---

## What is solved vs unsolved
### Solved enough to use now
1. The orbital problem is primarily a **radial support mapping** problem.
2. The support map depends strongly on curvature, coherence, and aether support.
3. The local band-appearance timing is derivable from effective constants and Doppler-effective traces.
4. The dominant timing variables are:
   - `scale_eff_doppler`
   - `omega_eff`
   - `R_eff`
   - `C_eff`
5. The local relativistic-correlation effect is a **small correction near unity**, not a huge arbitrary scale.

### Still not fully solved
1. The fully canonical timing-resolved **pairwise** relative-correlation law is not yet closed from the available logs.
2. The outer-band pair support is still weaker than desired.
3. The radial support mapper still needs a derived inner/outer placement correction built from relativistic/Doppler-effective channels, rather than from residual heuristics.
4. The model still needs a cleaner route from local support timing to fully native long-lived orbital placement without forced controls.

---

## What the next chat should do
### Immediate objective
Continue the research from the current state, using this package as the source of truth.

### Required approach
1. Read the uploaded code files, theory markdown, and artifact CSV/JSON files in this package.
2. Preserve the identity-preserving / environment-responsive split.
3. Keep all scaling tied to effective constants, relativistic correlation, dispersion, and Doppler-effective quantities.
4. Do not introduce arbitrary shell-scaling constants.
5. Focus next on deriving the **radial placement correction** and the **pairwise timing/correlation solve** from the logged effective channels.

### Suggested next concrete tasks
1. Rebuild the radial support mapper so that the inner and outer bands are placed by derived effective terms instead of fitted offsets.
2. Use the pair-channel replay data to derive a pairwise timing / support law from `Rel_ij`, `G_ij`, `Tpair_base_ij`, `Cgate_ij`, and `Tflux_ij`.
3. Rerun the DMT-native lithium absolute-zero simulation with:
   - the local timing law active
   - the new derived radial placement term active
   - pairwise effective logging preserved
4. Check whether the native peaks move toward the target bands (`2` and `6`) without forced orbitals.

### Important caution
The simulations so far are **toy / analogue research tools**. The next chat should be careful not to overstate the results as validated real-world particle or atomic physics.



## New in this rebuilt package
This package now includes a publication-style experiment ledger in `docs/EXPERIMENT_ARCHIVE.md` and a machine-readable run manifest in `docs/EXPERIMENT_MANIFEST.csv`. Use those as the primary continuation documents, not just the older summary docs.
