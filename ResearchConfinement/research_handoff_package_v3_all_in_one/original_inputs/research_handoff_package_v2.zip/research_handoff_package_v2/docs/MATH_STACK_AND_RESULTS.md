# MATH_STACK_AND_RESULTS_V2

This document is the v2 math stack for continuing the research. It is intentionally explicit about which quantities are treated as derived effective values and which combinations were used in continuation testing.

## Governing policy

- Preserve identity-preserving vs environment-responsive split.
- Treat all `_eff` quantities as derived effective values from relativistic correlation, stochastic dispersion, and Doppler-effective channels.
- Do not introduce arbitrary shell-scaling factors.
- Stay DMT-native unless a comparison/control run is required.
- Treat the current local timing law as the active working law, not the final answer.
- This remains a toy / analogue simulation research program.

## Effective constant layer

From the framework/equation stack, the effective constant layer is built from environment-derived versions of baseline quantities. The uploaded `constants_eq.py` should be treated as canonical for policy: `h_eff`, `k_b_eff`, `c_eff`, `e_charge_eff`, `mu_0_eff`, `epsilon_0_eff`, `scale_eff`, `stochastic_factor`, and `relativistic_corr` are derived rather than raw fixed values.

## Local timing law

`t_appear = 14.5729166667 + 1808.22336112*(omega_eff - 0.9957121838) - 275.99151246*(R_eff - 0.4425915037) + 1367.81476721*(C_eff - 0.3855790654) - 135161.28797655*(scale_eff_doppler - 1.0156430049)`

## Pair support, correction, and replay

### Pair support magnitude
`S_ij = Rel_ij^2 * O_ij * R_ij * Cgate_ij * Tpair_base_ij * Tflux_ij`

### Pairwise timing correction
`delta_t_pair(j) = t_local(j) * (1 - Rel_i_calc(j)) * sum_{i<j} S_ij`

`t_corrected(j) = t_local(j) - delta_t_pair(j)`

### Causal replay update
`n_j(t+1) = n_j(t) + dn_local_shifted_j(t+1) * (1 + sum_{i<j} S_ij * n_i(t) / n_i_final_baseline)`

## Explicit temporal/spatial quartet

For local band `i`:
- `T_const_eff_i = h_eff_i / h_eff_anchor`
- `X_const_eff_i = c_eff_i / c_eff_anchor`
- `T_const_doppler_i = h_eff_doppler_i / h_eff_i`
- `X_const_doppler_i = c_eff_doppler_i / c_eff_i`

Pair forms `ij` use the corresponding pairwise or averaged quantities.

### Quartet-combined derived terms
`gamma_ts = sqrt((T_const_doppler / T_const_eff) * (X_const_doppler / X_const_eff))`

`kappa_r = 1 / gamma_ts`

`xi_corr = gamma_ts / Rel_i_calc`

`eta_def = gamma_ts * (1 - Rel_i_calc)`

## Repulsion toy law used in continuation testing

This is not a claim about validated physics; it is the working mechanic tested in the toy model.

Charge separation sets quartet imbalance. Quartet imbalance generates leakage pressure. Leakage pressure projects outward as repulsion. Retention controls falloff.

### Leakage-pressure deficit
`eta_def_i = gamma_ts_i * (1 - Rel_i_calc_i)`

### Pair leakage and falloff
`leak_pair_ij = 0.5 * (eta_def_i + eta_def_j)`

`falloff_ij = 1 / (1 + sep_ij / (1 + 1000 * xret_avg_ij))`

### Repulsion
`repulsion_ij = charge_sep_ij * leak_pair_ij * falloff_ij`

## Explicit electron-particle state grammar

Promoted-particle update concept used in the later continuation line:

`S_e_k = {T_eff, X_eff, T_dopp, X_dopp, Rel, Leak, Ret, Cgate, Tflux, Rloc}`

`S_e_k(t+1) = Update_local(S_e_k(t)) + Sum_nucleus_pairs + Sum_electron_pairs`

Where pair contributions are decomposed into support-like and repulsion-like components.

## Hybrid nucleus split concept

The most promising architecture at handoff split nucleus influence into:
- identity-preserving anchor term
- softer environment-responsive radial authority term

The outer environment-responsive term was tested both as scalar and in axis-resolved or leakage-projected variants.

## Results snapshot

- Pairwise timing correction and causal replay improved `r6/r5` from ~`0.8108` to ~`0.8336`.
- Explicit quartet exposure changed the replay only slightly (`0.833632 -> 0.833697`), implying the quartet mattered but did not dominate alone.
- Axis-resolved support proxy improved the ratio much more strongly (~`0.8707`).
- Derived gate/retention improved long-run support but not clean early onset.
- Quartet-driven repulsion helped honestly, especially at stronger gain, but did not fully solve onset.
- Promoting electrons to explicit particles improved spacing and earlier outer stabilization.
- The hybrid nucleus split improved onset and ratio relative to lumped nucleus control.
- Moving axis directionality into leakage/retention projection alone produced only microscopic improvement.

## Recommended continuation target

Continue from the split nucleus + explicit electron-particle architecture. Keep the local timing law as the active seed, keep quartet-driven electron-electron repulsion in the model, and focus next on onset / occupancy shaping rather than refitting raw local timing or shell-scale factors.
