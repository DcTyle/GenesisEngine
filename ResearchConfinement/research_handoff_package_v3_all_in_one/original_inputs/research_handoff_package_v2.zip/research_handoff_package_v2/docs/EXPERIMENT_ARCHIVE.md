# Full Experiment Archive and Reproduction Ledger

This file is the **publication-style experiment archive** for the current research thread.
It is intended to let another chat continue the work without losing the exact sequence of tests, the active equations/assumptions in each pass, what each pass was probing, what numerical values came out, and which datasets/logs actually exist on disk.

This archive is honest about one important limitation:
- Some early runs were exploratory toy/operator studies performed before the logging/export layer was fully instrumented.
- For those runs, the **numerical results and the experiment design are preserved here**, but the raw event-level datasets were **not exported at the time**.
- Later runs **do** have exported datasets in `artifacts/`.

So this archive distinguishes between:
1. **Documented runs** — the run design and numerical outputs are preserved here.
2. **Dataset-backed runs** — the design, outputs, and raw/summary artifacts are preserved in `artifacts/`.

---

## Global research objective

We are trying to derive a **DMT-native, effective-constant, relativity-scaled orbital/support simulation** without arbitrary shell-scaling factors.

The long-chain target has been:
- identify which terms actually create stable support basins and shell bands,
- derive those terms from effective constants / relativistic correlation / Doppler-effective channels,
- expose timing and pairwise support values from simulation,
- and only then reintroduce more speculative temporal-coupling ideas.

Throughout the thread, the work repeatedly narrowed to this:

**the shell/orbital problem is first a radial-support-mapping problem, then a timing problem, and only later a temporal-coupling problem.**

---

## Source-of-truth files used across runs

### Theory/operator reference
- `src/DMT Publication .md`
- `src/Dimensional Modularity Theory (1).md`
- `src/GenesisSubstrate_eq.md`
- `src/confined_photon_delta_species_terms.md`
- `src/confined_photon_delta_species_terms_v5_unified.md`

### Equation/code spine
- `src/constants_eq.py`
- `src/hamiltonian_eq.py`
- `src/lattice9d_eq.py`
- `src/lorenz_eq.py`
- `src/measurement_eq.py`
- `src/pulse_eq.py`
- `src/qubit_eq.py`
- `src/schrodinger_eq.py`
- `src/sim_core.py`
- `src/state_eq.py`
- `src/stochastic_eq.py`
- `src/utils.py`

### Core effective-constant/operator equations actually used later
- `k_eff = k_ref * Rel * Disp`
- `omega_c_eff = M_eff * c_eff^2 / hbar_eff`
- `Xret_i = sum_j absorbed_exchange_ij`
- `Sigma_i = K_eff_i * C_i * R_i * O_orb_i * Rel_i * Tflux_i`
- reduced observable: `Sigma_eff = K_eff * C_eff * R_eff * Tflux_eff`
- normalized temporal-flux law:
  - `Tflux_i = 1 + alpha_tf_i * log(1 + omega_c_eff_i / omega_ref_i) * K_eff_i * Xret_i`
  - `Tflux_ij = 1 + alpha_tfp_ij * log(1 + sqrt(omega_c_eff_i * omega_c_eff_j) / omega_ref_ij) * absorbed_exchange_ij`
- pairwise correlation closure target:
  - `Rel_ij = sqrt( G_ij * (1 + Tself_eff_i + Tself_eff_j) / (O_ij * R_ij * Tpair_base_ij * Cgate_ij * Tflux_ij) )`

### DMT role split used in DMT-native baselines
- DOF 1–3: spatial
- DOF 4: temporal
- DOF 5: coherence
- DOF 6: flux
- DOF 7: phantom
- DOF 8: aether
- DOF 9: nexus

---

## Experiment archive (full chronological breakdown)

Each run below includes:
- **Purpose / hypothesis**
- **Simulation form**
- **Active terms / assumptions**
- **Observed outputs**
- **Interpretation**
- **Artifact status**

### Run 001 — 1D toy confined-light baseline
**Purpose**: check whether a single confined light-like packet shows leakage, width growth, and any coherent internal mode after 500 steps.

**Simulation form**:
- toy 1D confinement analogue
- finite confining region
- weak self-interaction
- 500 steps

**Active assumptions**:
- not a real QFT calculation
- used as a first analogue check for leakage/expansion/oscillation behavior

**Observed outputs**:
- leakage fraction outside box after 500 steps: `1.36e-5`
- width-growth / expansion constant: about `0.084` width-units per simulation-time unit
- dominant internal breathing mode: about `0.05` cycles / simulation-time unit
- angular frequency from that mode: about `0.314`
- phase-derived Compton-like analogue: about `0.00557` cycles / time unit
- no meaningful Hawking-like emission signature

**Interpretation**:
- small leakage exists
- coherent internal oscillation exists
- no thermal/horizon-like emission
- useful as a first motivation for using confinement, leakage, and recurrence as operator ingredients

**Artifact status**: documented only; no exported raw dataset.

---

### Run 002 — 2D toy confinement with 8 packets on 20x20 lattice
**Purpose**: test whether 8 confined photon-like packets with temporal coupling produce phase-orbital-like recurrence, anisotropic expansion, and leakage in 2D.

**Simulation form**:
- 20x20 lattice
- 8 confined photon-like packets
- 500 steps
- equations drawn from uploaded substrate/spec files

**Active assumptions**:
- phase anchor from amplitude/voltage/frequency
- coupled phase update using `dlnA` and `dlnf`
- pulse-driven axis scaling
- temporal-coupling endpoint-style term between start/current state
- product term using frequency × voltage

**Observed outputs**:
- mean net winding: about `2.81` turns over the run
- x-axis width growth: about `0.00165` per step
- y-axis width growth: about `0.00120` per step
- mean amplitude rose from `1.00` to about `2.05`
- edge leakage averaged about `12.35%`, ending about `11.64%`
- edge-emission peak: about `0.025` cycles / step
- no Hawking-like thermal broadband emission

**Interpretation**:
- clear phase-orbital-like recurrence
- systematic envelope growth
- leakage channel present
- but behavior wanted to self-amplify and saturate

**Artifact status**: documented only; no exported raw dataset.

---

### Run 003 — 2D stabilized rerun with temporal coupling gated by confinement and leakage
**Purpose**: stabilize the earlier 2D runaway by making temporal coupling only as strong as confinement / retention.

**Simulation form**:
- same 20x20 / 8-packet / 500-step toy basis

**Active assumptions**:
- `temporal_coupling_eff = temporal_coupling_raw * min(confinement, retention)` style gate
- leakage directly weakens coupling and amplitude/frequency growth

**Observed outputs**:
- final edge leakage: `0.0307`
- mean edge leakage: `0.0572`
- x growth: `0.00412` per step
- y growth: `0.00330` per step
- final amplitude: `0.20`
- final frequency: `0.02`
- final voltage: `0.02`
- final mass proxy: `0.1106`
- mean winding: `7.09` turns
- dominant edge-leak oscillation: about `0.02` cycles / step

**Interpretation**:
- lattice stabilized
- but system became over-damped
- useful negative result: direct leakage-based damping is too harsh

**Artifact status**: documented only.

---

### Run 004 — 2D overlap-mediated leakage absorption rerun
**Purpose**: make leakage bite hard only when absorbed by another packet via overlap, not merely when leakage exists.

**Simulation form**:
- same 20x20 / 8-packet toy basis

**Active assumptions**:
- decoupling applied only to absorbed leakage via overlap
- no forced absorption events

**Observed outputs**:
- mean overlap signal: `0.169`, final `0.130`
- mean absorbed-leakage transfer: `6.09e-4`, final `4.06e-4`
- final amplitude: `1.029`
- final frequency: `0.0805`
- final voltage: `0.1329`
- mean edge leak: `4.49e-4`
- final x width: `0.443`
- final y width: `1.036`
- mass saturated at cap in toy implementation

**Interpretation**:
- overlap emerged naturally
- weak absorption emerged
- system was more plausible than over-damped version
- but retention became too strong and mass saturated

**Artifact status**: documented only.

---

### Run 005 — 3D extension of overlap-mediated absorption
**Purpose**: test whether the same emergent overlap/absorption behavior survives in 3D.

**Simulation form**:
- 20x20x20 lattice
- 8 confined photon-like packets
- 1000 steps

**Active assumptions**:
- same overlap-mediated absorption logic as Run 004

**Observed outputs**:
- final edge leakage: `0.1031`
- mean edge leakage: `0.0848`
- final overlap signal: `0.000318`
- mean overlap signal: `0.000159`
- absorbed transfer: effectively `0`
- final amplitude: `2.4741`
- final frequency: `2.0`
- final voltage: `2.1`
- final mass-like value: `2.5412`
- width growth: x `-0.0001846`, y `+0.0006261`, z `-0.0000347`
- final widths: x `0.5669`, y `2.2048`, z `0.5479`
- mean winding: `0.1443`

**Interpretation**:
- geometry made overlap too weak in 3D
- particles mostly missed each other
- falsified the idea that 2D overlap behavior trivially generalizes to 3D

**Artifact status**: documented only.

---

### Run 006 — 3D with temporal coupling between particles exchanging leakage
**Purpose**: add a temporal-coupling factor specifically between particles exchanging leaked mass.

**Simulation form**:
- 20x20x20 lattice
- 8 packets
- 1000 steps
- using uploaded equation file as backbone

**Active assumptions**:
- exchange-only temporal coupling
- pairwise normalization through shared leakage events

**Observed outputs**:
- final edge leakage: `8.76e-05`
- mean edge leakage: `2.32e-04`
- final overlap: `0.00156`
- mean overlap: `0.01368`
- final absorbed transfer: `5.55e-06`
- final amplitude: `0.05`
- final frequency: `0.02`
- final voltage: `0.0294`
- final mass-like value: `0.02`
- final widths: x `1.8222`, y `1.9262`, z `1.8153`
- mean winding: `7.83` turns

**Interpretation**:
- stable but over-stabilized
- exchange existed but too weak
- energetic variables collapsed to floor values

**Artifact status**: documented only.

---

### Run 007 — 3D pairwise frequency normalization during shared leakage overlap
**Purpose**: derive a normalized state between particles only during shared leakage-overlap events, weakened by each packet’s self-coupling.

**Simulation form**:
- 20x20x20 lattice
- 8 confined packets
- 1000 steps

**Active assumptions**:
- normalization only during shared leakage overlap
- strength = pairwise temporal coupling × overlap, weakened by self-coupling

**Observed outputs**:
- about `3,870` overlap/exchange events
- mean overlap: `0.00184`
- mean absorbed transfer: `4.86e-06`
- pairwise frequency gap before normalization: `0.00358`
- after normalization: `0.00347`
- about `93.6%` of active events reduced the frequency gap
- average lock run: `5.1` steps
- longest lock run: `304` steps
- mean phase synchrony: `0.393`
- final amplitude: `0.682`
- final frequency: `2.292`
- final voltage: `2.504`
- final mass-like value: `1.816`
- final widths around `3.5, 3.68, 3.5`
- mean winding: `40.4` turns

**Interpretation**:
- not quantum, but a classical exchange-conditioned synchronization mechanism
- persistent orbital recurrence plus short locking episodes
- useful analogue result; not true entanglement

**Artifact status**: documented only.

---

### Run 008 — 3D tensor-gradient / DMT-style DOF mapping with temporal first and coherence fifth
**Purpose**: remove “extra geometry” and map per-axis DOF into tensor-gradient state, testing whether the coherence behavior survives.

**Simulation form**:
- 20x20x20 lattice
- 8 packets
- 1000 steps

**Active assumptions**:
- no extra geometry
- 6-component per-axis state: temporal, axial gradient, mixed gradients, coherence, flux
- temporal treated as first active non-spatial role, coherence as fifth in that experiment’s framing

**Observed outputs**:
- final edge leakage: `0.0970`
- mean overlap: `0.3060`, final `0.2215`
- mean absorbed mass-exchange: `0.00677`, final `0.00475`
- final amplitude: `1.6388`
- final frequency: `2.8145`
- final voltage: `2.2504`
- final mass-like value: `2.0795`
- final widths all hit cap `4.0`
- mean phase synchrony: `0.9015`
- overlap/exchange events: `27,970`
- average lock run: about `189` steps
- longest lock run: `988` steps
- mean winding: `17.25`

**Interpretation**:
- strong classical coherence locking
- too synchronization-friendly for computation
- but important because it showed local field-structure could create the effect without extra geometry

**Artifact status**: documented only.

---

### Run 009 — Photon-first vs electron-first regime correction
**Purpose**: test whether electron-like behavior should emerge from confined photon-like states rather than be primitive.

**Simulation form**:
- 20x20x20 lattice
- 8 photon-like packets
- 1000 steps

**Active assumptions**:
- no intrinsic mass growth in photon-like regime
- electron-like behavior only after confinement / coherence / orbital threshold

**Observed outputs**:
- all 8 transitioned later, around steps `521–557`, mean `538.9`
- overlap mean: `0.4033`, final `0.6262`
- absorbed exchange mean: `0.00244`, final `0.00567`
- mean leakage low: `7.88e-4`
- final amplitude: `3.5`
- final frequency: `3.0`
- final voltage: `3.2`
- final mass-like value: `6.0`
- final coherence: `2.5`
- widths about `3.27`
- mean synchrony: `0.386`, final `0.558`
- mean winding: `34.95`

**Interpretation**:
- photon-first ontology fit the framework better
- but post-transition regime still saturated too hard

**Artifact status**: documented only.

---

### Run 010 — Photon-native composite / hydrogen-like analogue attempts
**Purpose**: test whether photon-native packets could self-organize into proton-like / electron-like / shell-like regimes under confinement and leakage exchange.

**Simulation form**:
- multiple toy photon-native 3D runs
- one with 24 packets, one with 48 packets
- 1000 steps

**Active assumptions**:
- species treated as emergent regimes after the run
- no hardcoded particle species rules

**Observed outputs (24-packet run)**:
- 1 proton-like core, 3 electron-like shell objects, 8 additional shell-like, 12 propagating
- first hydrogen-like configuration around step `837`
- strongest hydrogen-like score about `0.95`

**Observed outputs (48-packet seed sweep)**:
- across 20 seeds: hydrogen-like analogue in `1` run, hydrogen-ion-like analogue in `3` runs
- average shell count around dominant core: `2.83`
- average proton-like core candidates: `4.0`
- average electron-like shell candidates: `2.75`

**Interpretation**:
- composite atom-like organization possible in toy regime language
- but shell/support selectivity too sloppy
- overbinding and shell crowding more important than seed luck

**Artifact status**: documented only.

---

### Run 011 — Publication-only DMT 9D conservation baseline (lithium-targeted)
**Purpose**: reset to a DMT-native baseline with no extra later coupling stack; determine what the publication role grammar alone produces.

**Simulation form**:
- 20x20x20 lattice
- 1000 steps
- lithium-targeted compact central seed with total normalized occupancy 7 and weak threefold phase perturbation

**Active assumptions**:
- DMT 9D role split only
- no v5 `Tflux_eff`, no pairwise `G_ij`, no species gates
- temporal modulation, coherence accumulation, flux transport, phantom radial feedback, aether lattice resonance, nexus integration

**Observed outputs**:
- conserved baseline drift: `1.45e-16`
- mean radius from center: `3.40`
- dominant radial band at `r ≈ 3`
- spatial substrate sum: `0.170`
- temporal ledger sum: `0.545`
- coherence ledger sum: `59.95`
- flux ledger sum: `36.77`
- aether ledger sum: `81.50`
- nexus ledger sum: `16.39`
- phantom magnitude sum: `0.0114`

**Interpretation**:
- stable conserved basin exists
- but no multi-shell orbital structure; one dominant basin only
- this became the key reset reference run

**Artifact status**: documented only.

---

### Run 012 — Parallel ablation sweep on added probe terms
**Purpose**: identify which added term actually creates a stable basin on top of the DMT baseline.

**Simulation form**:
- baseline plus parallel ablations
- terms individually and in selected combinations

**Terms tested**:
- null-style light handling
- post-confinement recurrence
- 4→5 bleed
- retained-exchange support
- emergent temporal coupling
- QFT-style mode support
- core-derived binding-spectrum support

**Observed outputs**:
- only `binding_spectrum` alone consistently created a tight stable basin
- `qft_modes` alone diffused outward
- temporal terms alone largely inert at this stage

**Full stack minus binding_spectrum**:
- primary basin at `r = 14`
- mean radius: `10.69`

**binding_spectrum only**:
- primary basin at `r = 2`
- mean radius: `2.45`

**Interpretation**:
- culprit is the **core-derived binding-spectrum extractor**
- shell/orbital problem narrowed to radial support mapping, not missing temporal coupling

**Artifact status**: documented only.

---

### Run 013 — Native radial-support subterm decomposition and forced-orbital control
**Purpose**: dissect the radial support mapper and determine what terms actually support forced orbital bands.

**Simulation form**:
- DMT-native radial mapper ablation
- separate forced-orbital control with imposed bands

**Native sweep outputs**:
- baseline no subterms: no shell peaks, mean radius `7.31`
- curvature only: condensed inward, mean radius `3.81`
- coherence only: one weak shell-like peak at `r = 4`, mean radius `4.66`
- flux only: mean radius `7.03`
- curvature + flux: one inner peak at `r = 2`, mean radius `3.77`
- all native terms: one inner peak at `r = 2`, mean radius `2.93`

**Forced-orbital control outputs**:
- forced bands at `r = 2` and `r = 6`
- inner band support contributions:
  - curvature `0.098`
  - aether `0.0019`
  - coherence `0.0050`
  - nexus `0.00027`
  - flux `-0.00043`
- outer band support contributions:
  - curvature `0.0386`
  - aether `0.00133`
  - coherence `0.0030`
  - nexus `0.00015`
  - flux `0.00005`

**Interpretation**:
- native DMT model wants one preferred radius
- forced shells reveal curvature as primary support, with aether/coherence stabilizing outer band
- flux mainly a corrective term

**Artifact status**: documented only.

---

### Run 014 — Forced-orbital inverse fit and native rerun
**Purpose**: infer a radial support mapper from the forced orbitals, then rerun natively with only the recovered mapper.

**Simulation form**:
- inverse fit from forced bands
- native rerun using recovered map only

**Recovered support peaks**:
- `r = 2`, support `0.954`
- `r = 6`, support `0.579`

**Recovered coefficient mix**:
- curvature: `-0.002`
- aether: `0.130`
- coherence: `1.158`
- flux: `-1.218`
- occupancy penalty: `0.257`
- bias: `0.0035`

**Native rerun outputs**:
- two long-lived peaks at `r = 4` and `r = 8`
- lifetimes: `998` and `1000` steps
- mean final radius: `5.55`
- run mean radius: `5.46`

**Interpretation**:
- qualitative two-band structure recovered
- but peaks shifted outward from target `2/6` to `4/8`
- narrowed problem to missing inner anchoring / placement term

**Artifact status**: documented only.

---

### Run 015 — Effective-constant / relativistic-correlation derivation pass using uploaded code spine
**Purpose**: replace heuristic inner-anchor values with relativistic-correlation-derived quantities from the uploaded Python files.

**Simulation form**:
- derivation pass against `constants_eq.py`, `hamiltonian_eq.py`, `lattice9d_eq.py`, `stochastic_eq.py`, and species-term files

**Key derived results**:
- local calibrated-basin correlation:
  - `Rel_i = Sigma_eff / (K_eff * C_eff * R_eff * O_orb * Tflux_eff)`
  - with reduced basis `O_orb = 1`, `Rel_i = 1.0000`
- consistency checks:
  - `rho_eff = Delta_species_binding / Tflux_eff = 1.69282633275`
  - `M_eff = Delta_species_binding / (C_eff * R_eff * Tflux_eff) = 2.0795`
  - `Xret_eff = (Tflux_eff - 1) / (omega_c_eff * K_eff) = 0.00475`

**Interpretation**:
- local anchor is fixed by the calibration basin; not arbitrary
- pairwise timing-resolved `Rel_ij` still underdetermined without more logged pair internals

**Artifact status**: documented only.

---

### Run 016 — Absolute-zero lithium diagnostic with appearance-time effective exposures
**Purpose**: expose effective constants and support context at first persistent shell-band appearance under a simplified environment.

**Simulation form**:
- lithium-targeted absolute-zero DMT-native diagnostic
- 24 deterministic runs
- first persistent appearance logging

**Dataset-backed artifacts**:
- `artifacts/lithium_abszero_peak_events.json`
- `artifacts/lithium_abszero_peak_summary.csv`

**Key outputs**:

**Inner band around r = 2**:
- count: `111`
- mean appearance step: `25.63`
- `Rel_i_required`: `1.0022 ± 0.0158`
- `Sigma_eff`: `0.2447`
- `K_eff`: `1.0421`
- `C_eff`: `0.3990`
- `R_eff`: `0.5893`
- `Tflux_eff`: `1.000189`
- `omega_eff`: `0.5473`
- `Xret_eff`: `9.95e-4`
- curvature: `0.5552`
- aether: `0.4856`
- coherence: `0.3868`
- flux: `0.00306`

**Outer band around r = 6**:
- count: `27`
- mean appearance step: `100.44`
- `Rel_i_required`: `0.9724 ± 0.0214`
- `Sigma_eff`: `0.09564`
- `K_eff`: `0.9460`
- `C_eff`: `0.3282`
- `R_eff`: `0.3083`
- `Tflux_eff`: `1.000001`
- `omega_eff`: `1.5159`
- `Xret_eff`: `2.87e-6`
- curvature: `0.1180`
- aether: `0.6313`
- coherence: `0.2720`
- flux: `0.01056`

**Interpretation**:
- absolute zero simplified the problem
- shell placement depended on small near-unity relativistic corrections, not huge scaling factors
- local band timing/placement could now be derived from effective traces

**Artifact status**: dataset-backed.

---

### Run 017 — Absolute-zero lithium effective and Doppler-effective exposure run
**Purpose**: expose effective constants and their Doppler-effective counterparts at first persistent band appearance.

**Simulation form**:
- absolute-zero lithium diagnostic
- first-persistent appearance logging
- effective and Doppler-effective constant exposure

**Dataset-backed artifacts**:
- `artifacts/lithium_abszero_effective_exposure_events.csv`
- `artifacts/lithium_abszero_effective_exposure_summary.csv`

**Key outputs**:

**Inner band r = 2**:
- mean appearance step: `5.0`
- `Rel_i_calc`: `0.94845`
- `relativistic_corr_eff`: `0.997401`
- `scale_eff`: `0.997401`
- `scale_eff_doppler`: `1.009708`
- `doppler_rel`: `1.012339`
- `K_eff`: `1.020413`
- `C_eff`: `0.452850`
- `R_eff`: `0.600000`
- `omega_eff`: `0.520000`
- `Xret_eff`: `9.93e-4`
- `Tflux_eff`: `1.000000116`
- `Sigma_eff`: `0.262950`

**Outer band r = 6**:
- mean appearance step: `30.875`
- `Rel_i_calc`: `0.693562`
- `relativistic_corr_eff`: `0.999822`
- `scale_eff`: `0.999822`
- `scale_eff_doppler`: `1.021593`
- `doppler_rel`: `1.021775`
- `K_eff`: `1.003291`
- `C_eff`: `0.329529`
- `R_eff`: `0.310184`
- `omega_eff`: `1.471690`
- `Xret_eff`: `1.16e-6`
- `Tflux_eff`: `1.00000000038`
- `Sigma_eff`: `0.092288`

**Interpretation**:
- bare effective constants stayed close to unity
- Doppler-effective counterparts separated bands much more clearly than base effective constants
- timing should key off Doppler-effective path, not raw effective constants alone

**Artifact status**: dataset-backed.

---

### Run 018 — Local timing-law derivation from effective/Doppler-effective exposures
**Purpose**: derive an actual timing calculator for band appearance from effective quantities.

**Simulation form**:
- regression/derivation pass on the exposure run

**Derived timing law**:
- `t_appear = 14.5729166667 + 1808.22336112*(omega_eff - 0.9957121838) - 275.99151246*(R_eff - 0.4425915037) + 1367.81476721*(C_eff - 0.3855790654) - 135161.28797655*(scale_eff_doppler - 1.0156430049)`

**Fit quality**:
- `R^2 = 0.99134`
- mean absolute timing error `≈ 0.858` steps

**Predicted bands**:
- `r = 2`: `5.09`, observed `5.00`
- `r = 3`: `4.91`, observed `5.00`
- `r = 5`: `17.39`, observed `17.42`
- `r = 6`: `30.91`, observed `30.88`

**Interpretation**:
- local appearance timing is now calculable from effective constants / Doppler-effective traces
- no arbitrary timing factor needed

**Artifact status**:
- model encoded in docs; event sources are dataset-backed by Run 017 artifacts.

---

### Run 019 — Timing-law replay with pairwise effective channel exposure
**Purpose**: replay the lithium absolute-zero baseline with the timing law active, and expose pairwise effective support channels at band activation.

**Simulation form**:
- timing-law replay using effective-constant timing calculator
- pairwise logging at replay-stage band activation

**Dataset-backed artifacts**:
- `artifacts/lithium_abszero_timinglaw_pair_channels.csv`
- `artifacts/lithium_abszero_timinglaw_replay_history.csv`
- `artifacts/lithium_abszero_timinglaw_replay_summary.csv`

**Replay outputs**:
- `r = 2` at step `4`
- `r = 3` at step `5`
- `r = 5` at step `18`
- `r = 6` at step `31`

**Pairwise effective channels**:
- inner pair `2–3`:
  - `Rel_ij = 0.91533`
  - `Tpair_base_ij = 1.02161`
  - `Cgate_ij = 0.42695`
  - `Tflux_ij = 1.00011549`
  - `G_ij = 0.08457`
- pair `2–5`:
  - `Rel_ij = 0.79367`
  - `Tpair_base_ij = 1.03328`
  - `Cgate_ij = 0.40231`
  - `Tflux_ij = 1.00000665`
  - `G_ij = 0.02713`
- pair `2–6`:
  - `Rel_ij = 0.81105`
  - `Tpair_base_ij = 1.03295`
  - `Cgate_ij = 0.38630`
  - `Tflux_ij = 1.00000641`
  - `G_ij = 0.01993`
- outer pair `5–6`:
  - `Rel_ij = 0.67870`
  - `Tpair_base_ij = 1.04417`
  - `Cgate_ij = 0.34318`
  - `Tflux_ij = 1.00000033`
  - `G_ij = 0.01777`

**Interpretation**:
- timing side is solved locally
- outer-band pair support is weaker than inner-band support
- next problem is now a pairwise support/placement correction, not timing exposure

**Artifact status**: dataset-backed.

---

## Current best scientific / engineering picture

### Things now reasonably established within the toy research program
1. A plain publication-only DMT baseline creates a stable conserved basin but not shell bands.
2. The main shell culprit is the radial support mapping / binding-spectrum extractor.
3. Forced-orbital controls and inverse fits show shell existence is possible, but placement is wrong without an inner anchoring correction.
4. At absolute zero, shell timing is controlled by **effective** and especially **Doppler-effective** traces, not by arbitrary shell-scaling knobs.
5. The local timing law is now numerically usable.
6. The next unresolved part is pairwise outer-band support.

### Things not yet honestly solved
1. A fully canonical, timing-resolved `Rel_ij(t)` solve from all pair internals in a fully native orbital-placement correction.
2. A native rerun that moves the spontaneous bands from the wrong 4/8 pattern to the desired 2/6 pattern **without** forced orbitals.
3. Closure of the stronger speculative temporal-coupling program on top of the now-recovered support/timing structure.

---

## Reproduction protocol for the next chat

If another chat is continuing this work, the correct sequence is:

1. Read all docs in `docs/` and all artifacts in `artifacts/`.
2. Treat Runs 016–019 as the primary dataset-backed reference runs.
3. Do **not** reintroduce arbitrary shell-scaling factors.
4. Use the timing law from Run 018 as the active local appearance rule.
5. Use the pairwise effective channels from Run 019 as the current pair-support baseline.
6. Focus next on deriving a **pairwise placement correction** that raises outer-band support while preserving the effective-constant spine.
7. Only after that should more speculative temporal-coupling / post-mass recurrence ideas be layered back in.

---

## Artifact map

Dataset-backed files and the runs they belong to:
- `artifacts/lithium_abszero_peak_events.json` -> Run 016
- `artifacts/lithium_abszero_peak_summary.csv` -> Run 016
- `artifacts/lithium_abszero_effective_exposure_events.csv` -> Run 017
- `artifacts/lithium_abszero_effective_exposure_summary.csv` -> Run 017
- `artifacts/lithium_abszero_timinglaw_pair_channels.csv` -> Run 019
- `artifacts/lithium_abszero_timinglaw_replay_history.csv` -> Run 019
- `artifacts/lithium_abszero_timinglaw_replay_summary.csv` -> Run 019

Early exploratory runs (001–015) are documented numerically here but do not have exported raw datasets in this package.
