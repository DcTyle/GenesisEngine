# README_CONTINUATION_V2

This is the rebuilt v2 continuation package. It contains:

- Original handoff package contents
- Full-experiment package docs and artifacts
- Uploaded framework/equation Python files in `framework files/`
- Continuation artifacts and scripts still present in the filesystem in `continuation_runs/`
- Publication-style documentation of the continuation runs in `docs/EXPERIMENT_ARCHIVE_V2.md`
- Updated math stack in `docs/MATH_STACK_AND_RESULTS.md`
- An updated continuation prompt in `docs/CONTINUATION_PROMPT_V2.txt`

Rebuild note:
Some prior generated files referenced in chat had expired from the filesystem before this package was rebuilt. Those runs are still documented in the archive docs, with their quoted numerical results and named output files, but only files present on disk at rebuild time could be embedded physically into the zip.
