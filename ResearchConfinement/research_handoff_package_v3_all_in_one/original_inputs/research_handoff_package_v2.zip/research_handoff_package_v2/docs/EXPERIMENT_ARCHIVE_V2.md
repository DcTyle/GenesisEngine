# EXPERIMENT_ARCHIVE_V2

This v2 handoff package is the continuation archive for the DMT-native toy/analogue simulation program discussed in this chat. It includes the original package contents, the full-experiment package contents, the uploaded framework/equation files, and the continuation artifacts that were still present in the filesystem when this archive was built.

Important honesty note: the user requested a byte-for-byte archive of everything previously run. Some prior transient artifacts referenced in chat were no longer present in the filesystem by the time this v2 package was rebuilt. Those runs are still documented below using the exact run intent, named artifacts, and numeric results quoted in the chat, but only the files still present on disk could be embedded directly into this zip.

## Research scope

This is a toy / analogue simulation research program, not validated real-world particle physics. The active line of work attempts to derive radial placement and timing behavior from DMT-native effective channels, with the identity-preserving vs environment-responsive split kept intact. `_eff` quantities are treated as derived effective values from relativistic correlation, dispersion, and Doppler-effective channels, never arbitrary free tuning constants.

## Core working laws and channel families

### Local timing law

`t_appear = 14.5729166667 + 1808.22336112*(omega_eff - 0.9957121838) - 275.99151246*(R_eff - 0.4425915037) + 1367.81476721*(C_eff - 0.3855790654) - 135161.28797655*(scale_eff_doppler - 1.0156430049)`

### Key local context values

- Local calibrated basin anchor: `Rel_i = 1.0000`
- Inner band target context (`r = 2`): `step ~ 5`, `Rel_i_calc ~ 0.94845`, `scale_eff_doppler ~ 1.009708`, `K_eff ~ 1.02041`, `C_eff ~ 0.45285`, `R_eff ~ 0.6`, `omega_eff ~ 0.52`
- Outer band target context (`r = 6`): `step ~ 30.875`, `Rel_i_calc ~ 0.69356`, `scale_eff_doppler ~ 1.021593`, `K_eff ~ 1.00329`, `C_eff ~ 0.32953`, `R_eff ~ 0.31018`, `omega_eff ~ 1.47169`

### Pair support form used in continuation work

`S_ij = Rel_ij^2 * O_ij * R_ij * Cgate_ij * Tpair_base_ij * Tflux_ij`

### Explicit temporal/spatial quartet

- `T_const_eff`
- `X_const_eff`
- `T_const_doppler`
- `X_const_doppler`

### Derived quartet-coupled terms used in back-calculation

- `gamma_ts = sqrt((T_const_doppler / T_const_eff) * (X_const_doppler / X_const_eff))`
- `kappa_r = 1 / gamma_ts`
- `xi_corr = gamma_ts / Rel_i_calc`
- `eta_def = gamma_ts * (1 - Rel_i_calc)`

## Run ledger

### Run family 1: pairwise effective placement correction
Intent: Use the current local timing law and derive/test a pairwise effective placement correction from logged pair channels (`Rel_ij`, `G_ij`, `Tpair_base_ij`, `Cgate_ij`, `Tflux_ij`) to move native bands toward target positions without forced orbitals.

Files embedded if present:
- `continuation_runs/next_pass_pairwise_correction.py`
- `continuation_runs/lithium_abszero_pairwise_correction_test.csv`
- `continuation_runs/lithium_abszero_pairwise_correction_test.json`

### Run family 2: causal pair replay pass
Intent: Keep the local timing law as the native seed and accumulate support causally from already-formed inner bins.
Quoted results from chat:
- `r5` first persistent step: `18 -> 17`
- `r6` first persistent step: `31 -> 30`
- `r5 final occupancy: 0.8290 -> 0.8725`
- `r6 final occupancy: 0.6721 -> 0.7274`
- `r6/r5 final ratio: 0.8108 -> 0.8336`

Files embedded if present:
- `continuation_runs/causal_pair_replay_pass.py`
- `continuation_runs/lithium_abszero_pairwise_timing_correction.csv`
- `continuation_runs/lithium_abszero_causal_pair_replay_history.csv`
- `continuation_runs/lithium_abszero_causal_pair_replay_summary.json`

### Run family 3: explicit temporal/spatial constant test
Intent: Expose the temporal/spatial effective constants and Doppler counterparts explicitly and thread them into the timing / replay correction.
Quoted results from chat:
- baseline `r6/r5 = 0.810775`
- raw pair-correction pass `r6/r5 = 0.833632`
- explicit constant pass `r6/r5 = 0.833697`
Interpretation: the quartet mattered, but only as a refinement; it did not dominate the correction.

### Run family 4: forced-orbital back-calculation
Intent: Use forced-orbital targets as a calibration scaffold and solve for residual structure the quartet still failed to explain.
Quoted values from chat:
- inner: `gamma_ts = 1.012339`, `kappa_r = 0.987811`, `xi_corr = 1.067363`, `eta_def = 0.052187`
- outer: `gamma_ts = 1.020531`, `kappa_r = 0.979882`, `xi_corr = 1.471435`, `eta_def = 0.312730`
Interpretation: the quartet alone was too smooth; the missing support asymmetry emerged when quartet terms were combined with local correlation deficit.

### Run family 5: axis-resolved support test
Intent: Replace scalar `support_gain_missing ~ f(xi_corr)` with per-axis or proxy-axis gains.
Quoted results from chat:
- baseline `r6/r5 = 0.8108`
- scalar pair-correction replay `r6/r5 = 0.8345`
- axis-resolved proxy replay `r6/r5 = 0.8707`
Quoted outer target gains:
- curvature / x-like: `2.443`
- aether / y-like: `0.443`
- coherence / z-like: `0.825`
Interpretation: the missing support behaved directionally rather than as a pure scalar deficit.

### Run family 6: sequential axis simulations
Intent: Run a proxy-axis control first, then derive equation-stack axis variables and rerun using the exposed variables.
Quoted results from chat:
- proxy current channels: `r6/r5 = 0.8707`
- equation-axis channels: `r6/r5 = 0.8181`
Interpretation: per-axis structure mattered, but the first direct equation-axis exposure was too smooth and underpowered relative to the empirical proxy.

### Run family 7: derived axis gate/retention two-pass
Intent: Derive per-axis gate and retention weights from mismatch targets and actuate them in the second sim.
Quoted results from chat:
- baseline `r6/r5 = 0.8108`
- sim1 proxy axis gate/retention `r6/r5 = 0.8247`
- sim2 derived axis gate/retention `r6/r5 = 0.9500`
Interpretation: long-run support ratio improved strongly, but outer onset remained crooked.

### Run family 8: quartet-driven repulsion test
Intent: Test the working theory that charge separation through the quartet causes leakage expansion, which projects as repulsion with falloff due to retention.
Quoted gain sweep from chat:
- gain `10`: `r6/r5 = 0.8518`
- gain `20`: `r6/r5 = 0.8702`
- gain `50`: `r6/r5 = 0.9248`
Interpretation: the repulsion idea helped honestly but did not by itself fix the onset problem. If large gain was needed, earlier correlation scaffolding may have been carrying too much of the fit.

### Run family 9: explicit electron-particle pass
Intent: Promote electrons to first-class particles with the same update grammar as nucleus-side dynamics.
Quoted results from chat:
- control, no e-e repulsion: `r6` first persistent occupancy above `0.2`: step `63`; final `r6/r2 = 0.3046`; final radii `2.035, 2.043, 6.499`
- explicit electrons + quartet-driven repulsion: `r6` first persistent above `0.2`: step `55`; final `r6/r2 = 0.3921`; final radii `1.811, 2.245, 6.411`
Interpretation: treating electrons as actual particles and giving them quartet-driven repulsion improved shell spacing without arbitrary shell factors.

### Run family 10: two-stage explicit-particle axis pass
Intent: Run control/proxy explicit-particle axis interactions, derive axis weights from mismatch, and actuate them in a second sim.
Quoted results from chat:
- sim1 ratio `0.4534`
- sim2 ratio `0.4641`
Interpretation: improved long-run balance slightly, but did not improve outer onset.

### Run family 11: dwell then quartet check
Intent: Try a per-axis temporal dwell/trigger term; if it failed, check whether overfitting in the nucleus was masking the actual cause.
Quoted results from chat:
- sim1 equal axis dwell: `r6` first persistent `>0.2` step `18`, ratio `0.5393`
- sim2 derived axis dwell: step `18`, ratio `0.4891`
- quartet overfit check: step `28`, ratio `0.3615`
Interpretation: dwell-axis derivation did not solve onset; nucleus likely carried too much radial authority, but pure quartet dominance was not better overall.

### Run family 12: hybrid nucleus split
Intent: Split nucleus influence into an identity-preserving anchor term and a softer environment-responsive radial authority term, keeping quartet-driven e-e repulsion active.
Quoted results from chat:
- lumped nucleus control: onset step `16`, ratio `0.5506`
- hybrid split nucleus: onset step `13`, ratio `0.6058`
- quartet-soft sanity run: onset step `31`, ratio `0.6369`
Interpretation: the nucleus had too much lumped authority; the better law is a split nucleus, not quartet-only dominance.

### Run family 13: hybrid axis-resolved environment-responsive radial authority
Intent: Make the softer nucleus term axis-resolved using effective-constant / Lorenz-style channels.
Quoted results from chat:
- scalar hybrid control: onset step `5`, ratio `0.4780`, outer radius `6.2132`
- axis-resolved hybrid: onset step `4`, ratio `0.3687`, outer radius `6.4829`
Interpretation: directionality here improved onset slightly but over-expanded outer radius and hurt retention.

### Run family 14: quartet leakage / retention projection on top of hybrid split
Intent: Keep the split nucleus scalar and move axis resolution into leakage transport / retention projection instead of radial authority.
Embedded files if present:
- `continuation_runs/quartet_leakage_projection_test.py`
- `continuation_runs/quartet_projection_hybrid_comparison.csv`
- `continuation_runs/quartet_projection_channels.csv`
- `continuation_runs/sim1_hybrid_scalar_control_history.csv`
- `continuation_runs/sim2_quartet_projected_history.csv`
- `continuation_runs/quartet_projection_hybrid_summary.json`
Quoted results from chat:
- control onset step `13`, ratio `0.612544`
- quartet projected onset step `13`, ratio `0.612561`
Interpretation: the effect was microscopic. The remaining onset miss was probably not explained by moving directionality into leakage/retention projection alone.

## Active research conclusions at handoff

1. The current local timing law is a good working law for native appearance seeding but not the final answer.
2. Outer-band weakness is not just “bad timing”; it is a support-geometry and interaction-structure problem.
3. Exposing the temporal/spatial quartet and Doppler counterparts is necessary for bookkeeping honesty, but those channels alone do not dominate the correction.
4. Directionality matters, but not every place to inject it is equally useful. Scalar or lumped nucleus terms tended to overfit radial authority; naive axis directionality often over-expanded outer placement unless retention was matched.
5. Explicit electron particles with the same update grammar as the nucleolus-side objects improved stability and spacing.
6. The most promising architecture in this continuation line was the split nucleus: identity-preserving anchor plus softer environment-responsive radial authority, with quartet-driven electron-electron repulsion active.
7. The remaining goblin at handoff is onset/occupancy shaping under that split architecture, not basic local timing or basic outer support.
