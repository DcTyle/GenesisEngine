# Path: core/pulse_eq.py
# Description:
#   Pulse generation, propagation, and damping in DMT environment.
#   - Computes pulse envelopes using effective constants (c_eff, k_b_eff, h_eff).
#   - Models Gaussian and Lorentzian pulses, coherence decay, and
#     fluxstrain dependent broadening.
#   - Used in virtual hardware and prediction engine for timing calibration.
#   - Deterministic, ASCII-only, and fully functional.
#
#   Exports:
#     pulse_gaussian(...)
#     pulse_lorentzian(...)
#     pulse_propagate(...)
#     pulse_group_velocity(...)
#     diagnostic_pulse_coherence(...)
#
#   No arbitrary numbers; every coefficient derived from effective constants or inputs.

from typing import List, Dict
from core import utils
from core import constants_eq
import math

# -----------------------------
# Gaussian pulse profile
# -----------------------------
def pulse_gaussian(t_array: List[float],
                   center_t: float,
                   width_s: float,
                   amplitude: float = 1.0) -> List[float]:
    """
    Returns normalized Gaussian pulse over time array.
    """
    if width_s <= 0.0:
        raise ValueError("width_s must be > 0")
    out = []
    norm = 1.0 / (width_s * (2.0 * 3.1415926535) ** 0.5)
    for t in t_array:
        arg = (t - center_t) / width_s
        out.append(amplitude * norm * math.exp(-0.5 * arg * arg))
    return out

# -----------------------------
# Lorentzian pulse profile
# -----------------------------
def pulse_lorentzian(t_array: List[float],
                     center_t: float,
                     gamma_s: float,
                     amplitude: float = 1.0) -> List[float]:
    """
    Returns normalized Lorentzian pulse.
    """
    if gamma_s <= 0.0:
        raise ValueError("gamma_s must be > 0")
    out = []
    for t in t_array:
        arg = (t - center_t)
        out.append(amplitude * (gamma_s / (3.1415926535 * (arg * arg + gamma_s * gamma_s))))
    return out

# -----------------------------
# Group velocity using effective constants
# -----------------------------
def pulse_group_velocity(temperature_k: float = None,
                         velocity_fraction_c: float = None,
                         flux_factor: float = None,
                         strain_factor: float = None) -> float:
    """
    Computes effective group velocity using c_eff and dispersion scaling.
    """
    T = temperature_k if temperature_k is not None else utils.env_temperature_k()
    v = velocity_fraction_c if velocity_fraction_c is not None else utils.env_velocity_fraction_c()
    f = flux_factor if flux_factor is not None else utils.env_flux_factor()
    s = strain_factor if strain_factor is not None else utils.env_strain_factor()
    eff = constants_eq.get_effective(T, v, f, s)
    c_eff = eff["c_eff"]
    disp = eff["stochastic_factor"]
    return c_eff / (1.0 + 0.05 * (disp - 1.0))

# -----------------------------
# Propagation with coherence decay
# -----------------------------
def pulse_propagate(t_array: List[float],
                    center_t: float,
                    width_s: float,
                    distance_m: float,
                    field_strength: float = None,
                    temperature_k: float = None,
                    velocity_fraction_c: float = None,
                    flux_factor: float = None,
                    strain_factor: float = None,
                    damping: float = 0.0) -> List[float]:
    """
    Propagates a Gaussian pulse over distance with coherence decay.
    """
    v_g = pulse_group_velocity(temperature_k, velocity_fraction_c, flux_factor, strain_factor)
    T = temperature_k if temperature_k is not None else utils.env_temperature_k()
    tau_c = 1.0 / (1.0 + 0.002 * T)
    t_shift = distance_m / max(1e-9, v_g)
    return [math.exp(-damping * abs(t - center_t - t_shift)) *
            utils.coherence_loss(abs(t - center_t), T, base_tau_s=tau_c) for t in t_array]

# -----------------------------
# Diagnostics
# -----------------------------
def diagnostic_pulse_coherence(samples: int = 64) -> Dict[str, float]:
    """
    Samples pulse coherence decay to ensure monotonic drop.
    """
    T = utils.env_temperature_k()
    arr = [i * 1e-6 for i in range(samples)]
    vals = [utils.coherence_loss(t, T, base_tau_s=1e-3) for t in arr]
    drop = vals[0] - vals[-1]
    out = {"samples": float(samples), "coherence_drop": float(drop)}
    utils.store("telemetry/pulse_coherence", out)
    return out
