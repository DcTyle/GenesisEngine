# Confined Photon Calibration Terms and Derived Delta Species Operators — v5.1 Hybrid Patch

VD sync not confirmed — operating on local context only.

This document is a **surgical patch-style continuation** of `confined_photon_delta_species_terms_v5_unified.md`. It preserves the same operator-family framing and markdown structure while appending the **hybrid corrections and reproduction math** derived from the later helium effective-Hamiltonian campaign.

This file is intended as a markdown handoff for continuation in a fresh chat.

It includes:

- the retained v5 backbone terms
- the hybrid patch terms added after the broad parallel stress campaign
- the exact operator vocabulary needed to reproduce the later surrogate helium results
- forward equations
- inverse / solved forms where they are useful
- the protected channels that should remain frozen during reproduction
- a compact reproducibility block
- a bottom test-data section containing only carried-forward targets / summary values, **not** the individual raw test runs

---

## 1. Scope of this patch

The prior `v5` file is kept as the canonical backbone for:

- effective retention
- effective coherence
- effective confinement
- retained mass-density persistence
- effective Compton recurrence
- retained exchanged leakage
- temporal-flux coupling
- support scalar `Sigma`
- `Delta_species_mass`
- `Delta_species_binding`
- universal pair coupling grammar

This patch adds the minimum extra structure that improved the later multi-line helium campaign:

- normalized temporal-flux response for numerical stability
- decoupled fine-structure environment response
- singlet-selective charge / asymmetry deformation channel
- hybrid effective Hamiltonian form used in the held-out line predictions
- compact reproduction math for the broad parallel stress campaign

The design goal of the patch is:

```text
v5 backbone + old singlet/charge deformation patch
```

not a full rewrite.

---

## 2. Retained canonical v5 backbone

The following terms are preserved from `v5` as the default operator spine.

```text
k_eff_i  = k_ref * Rel_i  * Disp_i
k_eff_ij = k_ref * Rel_ij * Disp_ij

omega_c_eff_i = M_eff_i * c_eff_i^2 / hbar_eff_i

X_ij    = O_ij * R_ij * Rel_ij
Xret_i  = sum_j absorbed_exchange_ij
rho_eff_i = M_i * C_i * R_i

Phi_curv_i = k_curv_eff_i * smooth(rho_eff around i)

K_eff_i     = K_base_i     * (1 + a_curv_eff_i * Phi_curv_i)
Tself_eff_i = Tself_base_i * (1 + b_curv_eff_i * Phi_curv_i)
lambda_eff_i = lambda_base_i / (1 + c_curv_eff_i * Phi_curv_i)

Sigma_i = K_eff_i * C_i * R_i * O_orb_i * Rel_i * Tflux_i

Delta_species_mass_i
Delta_species_binding_i
Tpair_ij
G_ij
Delta_f_ij
Delta_Q_ij
```

These are the protected channels for reproduction unless a later patch explicitly replaces them.

---

## 3. Normalized temporal-flux patch

The raw v5-style temporal-flux term is structurally correct but too eager to saturate when `omega_c_eff` becomes large.

The patched form used in the later campaign is:

```text
Tflux_i =
    1
    + alpha_tf_i
      * log(1 + omega_c_eff_i / omega_ref_i)
      * K_eff_i
      * Xret_i
```

Pairwise version:

```text
Tflux_ij =
    1
    + alpha_tfp_ij
      * log(1 + sqrt(omega_c_eff_i * omega_c_eff_j) / omega_ref_ij)
      * absorbed_exchange_ij
```

### Solved forms

Solve local retained exchange:

```text
Xret_i =
    (Tflux_i - 1)
    /
    (alpha_tf_i * log(1 + omega_c_eff_i / omega_ref_i) * K_eff_i)
```

Solve effective Compton recurrence:

```text
omega_c_eff_i =
    omega_ref_i
    *
    (
        exp((Tflux_i - 1) / (alpha_tf_i * K_eff_i * Xret_i))
        - 1
    )
```

Solve confinement:

```text
K_eff_i =
    (Tflux_i - 1)
    /
    (alpha_tf_i * log(1 + omega_c_eff_i / omega_ref_i) * Xret_i)
```

### Interpretation

This patch preserves the same causal role as the v5 temporal-flux term, but prevents `omega_c_eff` from instantly flattening all transition gates.

---

## 4. Decoupled fine-structure environment patch

The later environment sweeps showed that the bulk line centroid was stable while the fine-structure splitting inflated too quickly.

So the fine-structure environment response is separated from the bulk environment response.

Define:

```text
E_env_bulk_i = E_env_bulk_ref * F_env_i
E_env_fs_i   = E_env_fs_ref   * F_env_i^gamma_fs
```

where:

```text
gamma_fs in (0, 1)
```

and typically:

```text
gamma_fs << 1
```

for the decoupled branch response.

Equivalent operator form:

```text
Delta_temp_bulk = beta_temp_bulk * M_temp_bulk
Delta_temp_fs   = beta_temp_fs   * M_temp_fs
```

with:

```text
beta_temp_fs = beta_temp_fs_ref * F_env^gamma_fs
beta_temp_bulk = beta_temp_bulk_ref * F_env
```

### Solved forms

Solve `gamma_fs` from measured fine-structure deformation:

```text
gamma_fs =
    ln(beta_temp_fs / beta_temp_fs_ref)
    /
    ln(F_env)
```

Solve `F_env` from measured fine-structure deformation:

```text
F_env =
    (beta_temp_fs / beta_temp_fs_ref)^(1 / gamma_fs)
```

### Interpretation

This patch is what kept the `1083 nm` centroid stable while stopping the triplet spread from behaving like an over-coupled branch shear.

---

## 5. Singlet-selective charge / asymmetry deformation patch

The v5 calibration run resolved:

```text
Delta_species_charge_proxy = 0
```

which is clean, but it under-expresses the singlet side in later helium fitting.

The hybrid patch adds the **minimum singlet-selective charge/asymmetry channel** without reopening the entire parameter zoo.

Define:

```text
Qsrc_i =
    phase_bias_i
    * leakage_bias_i
    * outward_prop_bias_i
    * Rel_i
    * Tflux_i
    * S_singlet_i
```

where:

```text
0 <= S_singlet_i <= 1
```

and `S_singlet_i` is active primarily on singlet-sensitive branches.

Then:

```text
Delta_species_charge_i =
    Q_scale_i
    * tanh(beta_q * (Qsrc_i * K_eff_i * C_i - Sigma_q_thr))
```

### Solved forms

Define:

```text
Y_q = Delta_species_charge_i / Q_scale_i
```

Then:

```text
Qsrc_i =
    (
        Sigma_q_thr
        + artanh(Y_q) / beta_q
    )
    /
    (K_eff_i * C_i)
```

Solve singlet selector:

```text
S_singlet_i =
    Qsrc_i
    /
    (phase_bias_i * leakage_bias_i * outward_prop_bias_i * Rel_i * Tflux_i)
```

with the usual domain clamp for the `artanh` inverse.

### Interpretation

This is the **only** charge-like patch intentionally borrowed from the older set for the hybrid campaign. It should not be allowed to freely deform the full operator family.

---

## 6. Hybrid effective Hamiltonian form

The later helium campaign used a small effective Hamiltonian whose diagonal is anchored to spectral identity, with correction operators layered on top.

Canonical hybrid form:

```text
H_eff = H_spec_identity
      + beta_rel   * M_rel
      + beta_temp  * M_temp_bulk
      + beta_fs    * M_temp_fs
      + beta_mass  * M_mass
      + beta_bind  * M_bind
      + beta_qs    * M_q_singlet
      + beta_xs    * M_cross_substrate
```

where:

- `H_spec_identity` = spectrally anchored diagonal block
- `M_rel` = relativistic-correlation dressing mask
- `M_temp_bulk` = bulk temporal correction mask
- `M_temp_fs` = fine-structure temporal correction mask
- `M_mass` = mass-emergence deformation mask
- `M_bind` = binding-support deformation mask
- `M_q_singlet` = singlet-selective charge/asymmetry mask
- `M_cross_substrate` = cross-environment / cross-substrate mismatch mask

### Protected rule

The singlet patch should mainly feed:

```text
M_q_singlet
```

and only very lightly leak into:

```text
M_rel
```

It should **not** be allowed to globally retune all channels.

---

## 7. Helium spectral-identity base block used in the later campaign

Minimal six-state identity basis:

```text
{|2s_t>, |2s_s>, |2p_t0>, |2p_t1>, |2p_t2>, |2p_s>}
```

Identity-anchored diagonal block:

```text
H_spec_identity =
    diag(
        E_2s_t,
        E_2s_s,
        E_2p_t0,
        E_2p_t1,
        E_2p_t2,
        E_2p_s
    )
```

Carried-forward helium identity targets used in the later campaign are listed in the bottom test-data section.

A common reduced block form is:

```text
H_base(He) = E_2s_base * M_2s + E_2p_base * M_2p
```

with correction operators supplying singlet-triplet and fine-structure offsets.

---

## 8. Universal pair coupling retained in the hybrid patch

The pair coupling grammar is preserved, with only the temporal-flux normalization patch applied.

```text
Tpair_ij =
    Tpair_base_ij
    * Rel_ij
    * Cgate_ij
    * Tflux_ij
```

```text
G_ij =
    (X_ij * Tpair_ij)
    /
    (1 + Tself_eff_i + Tself_eff_j)
```

Expanded:

```text
G_ij =
    (
        O_ij
        * R_ij
        * Tpair_base_ij
        * Cgate_ij
        * Tflux_ij
        * Rel_ij^2
    )
    /
    (1 + Tself_eff_i + Tself_eff_j)
```

### Solved forms

Solve `Rel_ij`:

```text
Rel_ij =
    sqrt(
        G_ij * (1 + Tself_eff_i + Tself_eff_j)
        /
        (O_ij * R_ij * Tpair_base_ij * Cgate_ij * Tflux_ij)
    )
```

Solve `Tpair_base_ij`:

```text
Tpair_base_ij =
    G_ij * (1 + Tself_eff_i + Tself_eff_j)
    /
    (O_ij * R_ij * Cgate_ij * Tflux_ij * Rel_ij^2)
```

### Caution

The `Rel_ij^2` factor should be retained for reproduction parity, but it remains one of the first places to inspect if pair coupling becomes too stiff.

---

## 9. Frequency and charge normalization updates

Forward updates remain:

```text
Delta_f_ij = G_ij * (f_j - f_i)
Delta_Q_ij = G_ij * (Q_asym_j - Q_asym_i)
```

Post-update:

```text
f_i_next = f_i + Delta_f_ij
f_j_next = f_j - Delta_f_ij

Q_asym_i_next = Q_asym_i + Delta_Q_ij
Q_asym_j_next = Q_asym_j - Delta_Q_ij
```

### Solved forms

```text
G_ij = Delta_f_ij / (f_j - f_i)
```

```text
G_ij = Delta_Q_ij / (Q_asym_j - Q_asym_i)
```

---

## 10. Inverse-gate stability rules

Any reproduction should clamp gate inversions.

For sigmoid-style inversions:

```text
Y_clamped = clamp(Y, eps, 1 - eps)
```

For `artanh` inversions:

```text
Y_clamped = clamp(Y, -1 + eps, 1 - eps)
```

Then use:

```text
ln(Y_clamped / (1 - Y_clamped))
artanh(Y_clamped)
```

This is required to prevent the inverse solve from becoming numerically singular.

---

## 11. Cross-substrate environment deformation term

The later campaign indicated that cross-substrate mismatch matters more than raw temperature for some observables.

Define a separate mismatch scalar:

```text
chi_env(A,B) = cross_environment_correlation(A, B)
```

and operator contribution:

```text
Delta_cross_substrate = beta_xs * chi_env(A,B) * M_cross_substrate
```

### Solved form

```text
chi_env(A,B) = Delta_cross_substrate / (beta_xs * M_cross_substrate)
```

This term should remain separate from the local `Rel_i` and pairwise `Rel_ij` channels.

---

## 12. Curvature-consistency diagnostic

The hybrid campaign benefits from explicitly comparing the three curvature estimates implied by:

- confinement
- self-temporal coupling
- leakage suppression

Define:

```text
Phi_from_K_i = (K_eff_i / K_base_i - 1) / a_curv_eff_i
Phi_from_Tself_i = (Tself_eff_i / Tself_base_i - 1) / b_curv_eff_i
Phi_from_lambda_i = (lambda_base_i / lambda_eff_i - 1) / c_curv_eff_i
```

Consistency score:

```text
Xi_consistency_i =
    1
    /
    (
        1
        + |Phi_from_K_i - Phi_from_Tself_i|
        + |Phi_from_K_i - Phi_from_lambda_i|
    )
```

This was not itself a scored line observable, but it is useful for detecting numerically forced species transitions.

---

## 13. Full coupled update block for reproduction

Use this block as the compact hybrid operator grammar.

```text
Rel_i      = relativistic_correlation(state_i, ctx)
Rel_ij     = relative_correlation(state_i, state_j, ctx)
Disp_i     = stochastic_dispersion_factor(state_i, ctx)
Disp_ij    = stochastic_dispersion_factor_pair(state_i, state_j, ctx)

c_eff_i    = c_ref    * Rel_i * Disp_i
hbar_eff_i = hbar_ref * Rel_i * Disp_i

omega_c_eff_i = M_eff_i * c_eff_i^2 / hbar_eff_i

X_ij = O_ij * R_ij * Rel_ij
absorbed_exchange_ij = Aabs_ij * X_ij
Xret_i = sum_j absorbed_exchange_ij

rho_eff_i = M_i * C_i * R_i
Phi_curv_i = k_curv_eff_i * smooth(rho_eff around i)

K_eff_i = K_base_i * (1 + a_curv_eff_i * Phi_curv_i)
Tself_eff_i = Tself_base_i * (1 + b_curv_eff_i * Phi_curv_i)
lambda_eff_i = lambda_base_i / (1 + c_curv_eff_i * Phi_curv_i)

Tflux_i =
    1
    + alpha_tf_i
      * log(1 + omega_c_eff_i / omega_ref_i)
      * K_eff_i
      * Xret_i

Tflux_ij =
    1
    + alpha_tfp_ij
      * log(1 + sqrt(omega_c_eff_i * omega_c_eff_j) / omega_ref_ij)
      * absorbed_exchange_ij

Sigma_i = K_eff_i * C_i * R_i * O_orb_i * Rel_i * Tflux_i

Delta_species_mass_i =
    M_scale_i
    / (1 + exp(-beta_m * (Sigma_i - Sigma_m_thr)))
    - M_photon_ref

Qsrc_i =
    phase_bias_i
    * leakage_bias_i
    * outward_prop_bias_i
    * Rel_i
    * Tflux_i
    * S_singlet_i

Delta_species_charge_i =
    Q_scale_i
    * tanh(beta_q * (Qsrc_i * K_eff_i * C_i - Sigma_q_thr))

Bsrc_i = K_eff_i * C_i * R_i * Phi_curv_i * Tflux_i

Delta_species_binding_i =
    B_scale_i
    / (1 + exp(-beta_b * (Bsrc_i - Sigma_b_thr)))

Tpair_ij = Tpair_base_ij * Rel_ij * Cgate_ij * Tflux_ij

G_ij = (X_ij * Tpair_ij) / (1 + Tself_eff_i + Tself_eff_j)

Delta_f_ij = G_ij * (f_j - f_i)
Delta_Q_ij = G_ij * (Q_asym_j - Q_asym_i)

H_eff =
    H_spec_identity
    + beta_rel  * M_rel
    + beta_temp * M_temp_bulk
    + beta_fs   * M_temp_fs
    + beta_mass * M_mass
    + beta_bind * M_bind
    + beta_qs   * M_q_singlet
    + beta_xs   * M_cross_substrate
```

---

## 14. Reproducibility notes for another chat

To reproduce the later campaign without replaying the individual tests themselves:

1. Freeze the v5 backbone terms.
2. Replace raw temporal-flux with the normalized `log(1 + omega / omega_ref)` form.
3. Split bulk temporal deformation from fine-structure temporal deformation.
4. Add only the singlet-selective charge/asymmetry patch.
5. Keep the hybrid Hamiltonian small and identity-anchored.
6. Score against multiple helium observables simultaneously rather than one line at a time.
7. Treat cross-substrate mismatch as its own operator channel.
8. Clamp inverse gates.
9. Preserve the pair-coupling grammar.
10. Track curvature-consistency as a diagnostic.

---

## 15. Compact solved handoff block

Paste this into the next chat if the continuation needs to stay anchored to the hybrid patch.

```text
Hybrid patch = v5 backbone + singlet-selective charge/asymmetry patch

Protected channels:
- k_eff
- omega_c_eff
- Xret
- Phi_curv -> K_eff, Tself_eff, lambda_eff
- Tflux (normalized log form)
- Sigma
- Delta_species_mass
- Delta_species_binding
- Tpair
- G_ij
- Delta_f_ij

Normalized temporal flux:
Tflux_i = 1 + alpha_tf_i * log(1 + omega_c_eff_i / omega_ref_i) * K_eff_i * Xret_i

Decoupled fine-structure environment response:
beta_temp_fs = beta_temp_fs_ref * F_env^gamma_fs
beta_temp_bulk = beta_temp_bulk_ref * F_env

Singlet-selective charge patch:
Qsrc_i = phase_bias_i * leakage_bias_i * outward_prop_bias_i * Rel_i * Tflux_i * S_singlet_i
Delta_species_charge_i = Q_scale_i * tanh(beta_q * (Qsrc_i * K_eff_i * C_i - Sigma_q_thr))

Hybrid Hamiltonian:
H_eff = H_spec_identity
      + beta_rel  * M_rel
      + beta_temp * M_temp_bulk
      + beta_fs   * M_temp_fs
      + beta_mass * M_mass
      + beta_bind * M_bind
      + beta_qs   * M_q_singlet
      + beta_xs   * M_cross_substrate

Key diagnostics:
- line centroid error
- multiplet spread error
- RMS relative error across multi-line helium targets
- Xi_consistency_i
- propagation norm drift
```

---

## 16. Test data (carried-forward targets and summary values only)

This section intentionally contains **summary targets and campaign outcomes**, not the individual raw test runs.

### 16.1 Photon-run carried-forward v5 calibration values

```text
R_eff                      = 0.9030
C_eff                      = 0.9015
K_eff                      = 1.0000
rho_eff                    = 1.69282633275
omega_c_eff                = 2.0795
Xret_eff                   = 0.00475
Tflux_eff                  = 1.009877625
Sigma_eff                  = 0.8220954250805624

Delta_species_mass         = 2.0795
Delta_species_binding      = 1.7095474364550294
Delta_species_charge_proxy = 0
```

### 16.2 Helium spectral-identity targets carried forward

```text
2s triplet = 19.819000 eV
2s singlet = 20.615000 eV
2p triplet j0 = 20.963868 eV
2p triplet j1 = 20.963879 eV
2p triplet j2 = 20.964000 eV
2p singlet = 21.218000 eV
```

### 16.3 Held-out helium line targets carried forward

```text
1083 nm triplet centroid target = 1082.909110 nm
706.52 nm triplet target lines =
    706.517710 nm
    706.521530 nm
    706.570860 nm
667.815 nm singlet target = 667.815170 nm
587.56 nm triplet target lines =
    587.561480 nm
    587.564040 nm
    587.596630 nm
```

### 16.4 Summary outcome of the later comparative campaigns

```text
v5 outperformed the older set overall on basin stability.

The hybrid (v5 backbone + singlet patch) slightly outperformed both parents
on the joint multi-line stress campaign while preserving v5-style stability.

Representative campaign-scale summary:
- structured-grid mean RMS: hybrid slightly lower than v5, both lower than old
- extreme-random mean RMS: hybrid slightly lower than v5, both lower than old
- worst observed held-out line errors remained far below 6 percent
- propagation norm drift remained at numerical-dust scale
```

### 16.5 Protected interpretation

These are effective / surrogate campaign observables, not Standard Model masses, charges, or binding energies.

```text
Delta_species_mass    = emergent mass-like persistence deformation
Delta_species_charge  = emergent charge-like asymmetry deformation
Delta_species_binding = emergent binding-support deformation
```

All three remain tied to:

- relativistic correlation
- pairwise relative correlation
- temporal-flux coupling
- retained exchanged leakage
- confinement
- Compton-frequency recurrence of the mass-bearing regime
- spectral identity anchoring

