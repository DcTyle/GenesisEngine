# Math stack and results summary

## A. Equations actively referenced during the current work

### Effective constants
- `k_eff = k_ref * Rel * Disp`
- `omega_c_eff = M_eff * c_eff^2 / hbar_eff`
- `Xret_i = sum_j absorbed_exchange_ij`
- `Sigma_i = K_eff_i * C_i * R_i * O_orb_i * Rel_i * Tflux_i`
- reduced observable form: `Sigma_eff = K_eff * C_eff * R_eff * Tflux_eff`

### Normalized temporal-flux law from the hybrid/v5 bridge
- `Tflux_i = 1 + alpha_tf_i * log(1 + omega_c_eff_i / omega_ref_i) * K_eff_i * Xret_i`
- `Tflux_ij = 1 + alpha_tfp_ij * log(1 + sqrt(omega_c_eff_i * omega_c_eff_j) / omega_ref_ij) * absorbed_exchange_ij`

### Pairwise relative-correlation closure
- `Rel_ij = sqrt( G_ij * (1 + Tself_eff_i + Tself_eff_j) / (O_ij * R_ij * Tpair_base_ij * Cgate_ij * Tflux_ij) )`

### Local relativistic-correlation anchor from reduced basin
- `Rel_i = Sigma_eff / (K_eff * C_eff * R_eff * O_orb * Tflux_eff)`
- for the reduced calibrated basis with `O_orb = 1`, `Rel_i = 1.0`

## B. Timing law derived from absolute-zero lithium exposure
- `t_appear = 14.5729166667 + 1808.22336112*(omega_eff - 0.9957121838) - 275.99151246*(R_eff - 0.4425915037) + 1367.81476721*(C_eff - 0.3855790654) - 135161.28797655*(scale_eff_doppler - 1.0156430049)`

Quality of fit:
- `R^2 = 0.99134`
- mean absolute error `~0.858` steps

## C. Band appearance values from the exposed effective traces
### Radius bin 2
- appearance step mean: `5.0`
- `Rel_i_calc = 0.9484488059413904`
- `relativistic_corr_eff = 0.997401178611188`
- `scale_eff_doppler = 1.0097083040698238`
- `K_eff = 1.0204134246436225`
- `C_eff = 0.4528496706784569`
- `R_eff = 0.6`
- `omega_eff = 0.52`
- `Xret_eff = 9.9318679432738e-4`
- `Sigma_eff = 0.26294950801064737`

### Radius bin 6
- appearance step mean: `30.875`
- `Rel_i_calc = 0.693561558023094`
- `relativistic_corr_eff = 0.999822247149125`
- `scale_eff_doppler = 1.0215930682787782`
- `K_eff = 1.0032913015364382`
- `C_eff = 0.3295289092423035`
- `R_eff = 0.3101842964141107`
- `omega_eff = 1.4716898260003575`
- `Xret_eff = 1.162338607844842e-6`
- `Sigma_eff = 0.09228785028803077`

## D. Pairwise effective channels from timing-law replay
### Inner pair 2-3
- `Rel_ij = 0.91533`
- `Tpair_base_ij = 1.02161`
- `Cgate_ij = 0.42695`
- `Tflux_ij = 1.00011549`
- `G_ij = 0.08457`

### Pair 2-5
- `Rel_ij = 0.79367`
- `Tpair_base_ij = 1.03328`
- `Cgate_ij = 0.40231`
- `Tflux_ij = 1.00000665`
- `G_ij = 0.02713`

### Pair 2-6
- `Rel_ij = 0.81105`
- `Tpair_base_ij = 1.03295`
- `Cgate_ij = 0.38630`
- `Tflux_ij = 1.00000641`
- `G_ij = 0.01993`

### Outer pair 5-6
- `Rel_ij = 0.67870`
- `Tpair_base_ij = 1.04417`
- `Cgate_ij = 0.34318`
- `Tflux_ij = 1.00000033`
- `G_ij = 0.01777`

## E. Main current conclusion
- the shell/orbital problem is a radial support mapping problem first
- the local timing of shell appearance is now calculable from effective constants and Doppler-effective traces
- the next unsolved piece is the pairwise support / placement correction for the outer band
