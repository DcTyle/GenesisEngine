# Pass 16 Implementation Matrix

Scope: continue the J-series with one bounded clear-owner annotation tranche only. No new runner behavior, no new substrate classes, no synonym paths, no parser changes.

## Target files

| File | Classification | Substrate | Artifact class | Reason |
|---|---|---:|---:|---|
| `include/GE_audio_features.hpp` | implement | `ai_asset_vault` | `interface_header` | deterministic audio feature contract belongs to the AI speech/asset knowledge lane |
| `src/GE_audio_features.cpp` | implement | `ai_asset_vault` | `implementation_unit` | CPU reference feature extractor feeding measurable AI audio artifacts |
| `include/GE_audio_wav.hpp` | implement | `ai_asset_vault` | `interface_header` | canonical WAV artifact contract for the speech lane |
| `src/GE_audio_wav.cpp` | implement | `ai_asset_vault` | `implementation_unit` | deterministic audio container IO in the same speech/asset lane |
| `include/GE_g2p_english.hpp` | implement | `ai_asset_vault` | `interface_header` | grapheme-to-phoneme interface is clear AI language asset ownership |
| `src/GE_g2p_english.cpp` | implement | `ai_asset_vault` | `implementation_unit` | deterministic English G2P implementation feeding voice artifacts |
| `include/GE_g2p_lexicon.hpp` | implement | `ai_asset_vault` | `interface_header` | lexicon data contract is unambiguously AI language asset material |
| `src/GE_g2p_lexicon.cpp` | implement | `ai_asset_vault` | `implementation_unit` | lexicon realization remains in the same lane |
| `include/GE_forced_aligner.hpp` | implement | `ai_asset_vault` | `interface_header` | alignment interface belongs to the AI speech asset/tooling lane |
| `src/GE_forced_aligner.cpp` | implement | `ai_asset_vault` | `implementation_unit` | deterministic forced-alignment logic produces AI-owned speech artifacts |
| `include/GE_speech_alignment.hpp` | implement | `ai_asset_vault` | `interface_header` | speech alignment contract is a clear AI knowledge/asset surface |
| `src/GE_speech_alignment.cpp` | implement | `ai_asset_vault` | `implementation_unit` | alignment implementation sits on the same canonical speech lane |
| `include/GE_voice_predictive_model.hpp` | implement | `ai_asset_vault` | `interface_header` | predictive voice model contract is clearly AI asset-vault material |
| `src/GE_voice_predictive_model.cpp` | implement | `ai_asset_vault` | `implementation_unit` | deterministic voice model implementation remains in the same lane |
| `include/GE_voice_synth.hpp` | implement | `ai_asset_vault` | `interface_header` | voice synthesis interface is part of the AI speech asset path |
| `src/GE_voice_synth.cpp` | implement | `ai_asset_vault` | `implementation_unit` | self-hosted synthesis implementation remains in the clear-owner speech lane |

## Pass 16 constraints satisfied

- one canonical runner only
- no new substrate values
- no routing heuristics
- no mass-annotation outside the bounded speech/language tranche
- no duplicate source-of-truth logic
