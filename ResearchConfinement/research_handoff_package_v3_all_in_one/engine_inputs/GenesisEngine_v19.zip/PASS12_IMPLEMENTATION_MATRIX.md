# PASS 12 IMPLEMENTATION MATRIX — Annotation-driven CPU-to-substrate ingestion (J-series tranche 1)

## Scope
This pass starts the dedicated J-series with one canonical annotation-driven ingestion pipeline. It implements J1, J2, J3, J4, J5-first-tranche, J6, and the non-destructive J7 workflow support in bounded form.

## File-by-file matrix

| File | Status | Role in Pass 12 |
|---|---|---|
| `include/GE_substrate_annotation_ingest.hpp` | New | Canonical parser/route/report API for annotation-driven ingestion |
| `src/GE_substrate_annotation_ingest.cpp` | New | Deterministic runner: scan approved roots, parse top-of-file annotations, canonicalize, encode, route, report |
| `src/tools/ge_substrate_ingest_main.cpp` | New | CLI entrypoint for dry-run/apply ingestion using the canonical runner |
| `CMakeLists.txt` | Updated | Wires canonical ingest support into `EigenWareCore` and adds `ge_substrate_ingest` executable |
| `docs/GENESIS_SUBSTRATE_ANNOTATION_SCHEMA.md` | New | Canonical schema and routing-table documentation for v1 |
| `include/substrate_alu.hpp` | Updated | First-tranche clear-owner annotation: `microprocessor` |
| `src/substrate_alu.cpp` | Updated | First-tranche clear-owner annotation: `microprocessor` |
| `include/substrate_harmonics.hpp` | Updated | First-tranche clear-owner annotation: `microprocessor` |
| `src/substrate_harmonics.cpp` | Updated | First-tranche clear-owner annotation: `microprocessor` |
| `include/GE_ai_vault.hpp` | Updated | First-tranche clear-owner annotation: `ai_asset_vault` |
| `src/GE_ai_vault.cpp` | Updated | First-tranche clear-owner annotation: `ai_asset_vault` |
| `include/GE_coherence_graph_store.hpp` | Updated | First-tranche clear-owner annotation: `coherence_observation` |
| `src/GE_coherence_graph_store.cpp` | Updated | First-tranche clear-owner annotation: `coherence_observation` |

## Contract closure by requirement

- **J1 strict annotation schema**: implemented with required keys and exact top-of-file parsing.
- **J2 canonical ingestion runner**: implemented with approved-root scan, dry-run/apply, deterministic ordering, and report emission.
- **J3 substrate routing table**: implemented for `microprocessor`, `ai_asset_vault`, and `coherence_observation` only.
- **J4 reuse canonical symbol/spectral path**: implemented through strict UTF-8 canonicalization, `coord_sig9`, `ew_bytes_to_frequency_code`, and CUDA SpiderCode4/carrier collapse when applying.
- **J5 first migration tranche only**: only eight clear-owner files were annotated in this pass.
- **J6 deterministic reporting/conflict handling**: implemented via TSV + summary categories.
- **J7 deprecation workflow, not deletion**: supported via `@canonical: deprecated` classification and report path, with no auto-delete behavior.
