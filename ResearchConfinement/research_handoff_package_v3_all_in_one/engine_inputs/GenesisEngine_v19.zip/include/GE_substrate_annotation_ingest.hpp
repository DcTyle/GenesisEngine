#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "GE_corpus_anchor_store.hpp"
#include "GE_corpus_pulse_log.hpp"
#include "GE_corpus_canonicalizer.hpp"
#include "ew_id9.hpp"

struct GE_SubstrateAnnotation {
    std::string substrate_utf8;
    std::string artifact_class_utf8;
    bool ingest_enabled = false;
    enum class CanonicalState : uint8_t {
        FalseState = 0,
        TrueState = 1,
        Deprecated = 2,
    } canonical_state = CanonicalState::FalseState;

    bool has_substrate = false;
    bool has_artifact_class = false;
    bool has_ingest = false;
    bool has_canonical = false;
    bool malformed = false;
    bool conflicting = false;
    std::string issue_utf8;
};

struct GE_SubstrateRoute {
    const char* substrate_ascii = nullptr;
    uint8_t lane_u8 = 0;
    EwId9 domain_id9{};
};

enum class GE_SubstrateIngestCategory : uint8_t {
    Ingested = 0,
    Skipped = 1,
    Unannotated = 2,
    MalformedAnnotation = 3,
    ConflictingAnnotation = 4,
    UnknownSubstrate = 5,
    DeprecatedCandidate = 6,
};

struct GE_SubstrateIngestRecord {
    std::string relpath_utf8;
    std::string substrate_utf8;
    std::string artifact_class_utf8;
    GE_SubstrateIngestCategory category = GE_SubstrateIngestCategory::Skipped;
    uint8_t lane_u8 = 0;
    EwId9 source_id9{};
    EwId9 artifact_id9{};
    uint32_t seq_u32 = 0;
    uint32_t canonical_bytes_u32 = 0;
    int32_t frequency_code_s32 = 0;
    std::string note_utf8;
};

struct GE_SubstrateIngestArtifactBundle {
    std::string substrate_utf8;
    GE_CorpusAnchorStore anchor_store;
    GE_CorpusPulseLog pulse_log;
    uint32_t next_seq_u32 = 0;
};

struct GE_SubstrateIngestReport {
    std::vector<GE_SubstrateIngestRecord> records;
    GE_CorpusCanonicalizeStats canonicalize_stats{};
    uint32_t ingested_count_u32 = 0;
    uint32_t skipped_count_u32 = 0;
    uint32_t unannotated_count_u32 = 0;
    uint32_t malformed_count_u32 = 0;
    uint32_t conflicting_count_u32 = 0;
    uint32_t unknown_substrate_count_u32 = 0;
    uint32_t deprecated_count_u32 = 0;
};

struct GE_SubstrateIngestOptions {
    std::string repo_root_utf8;
    std::vector<std::string> approved_roots_utf8;
    std::string out_dir_utf8;
    bool apply_mode = false;
};

bool GE_parse_top_of_file_substrate_annotation(const std::string& text_utf8,
                                               GE_SubstrateAnnotation& out);

const GE_SubstrateRoute* GE_find_substrate_route_ascii(const std::string& substrate_utf8);

bool GE_run_substrate_annotation_ingest(const GE_SubstrateIngestOptions& opt,
                                        GE_SubstrateIngestReport& out_report);

bool GE_write_substrate_ingest_report(const std::string& out_dir_utf8,
                                      const GE_SubstrateIngestReport& report);
