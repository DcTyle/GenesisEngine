# Pass 18 Implementation Matrix

Pass focus: continue the annotation-driven CPU-to-substrate ingestion series with one bounded clear-owner tranche only.

Classification for Pass 18 lane:

| File | Classification | Canonical substrate | Reason |
|---|---|---:|---|
| `include/GE_budget_helpers.hpp` | missing | `microprocessor` | Deterministic carrier budget helpers directly shape substrate work admission. |
| `include/GE_causality_clamp.hpp` | missing | `microprocessor` | Canonical causality clamp for transported phase per tick. |
| `include/GE_fft_fixed.hpp` | missing | `microprocessor` | Fixed-point FFT primitive used by substrate spectral operators. |
| `src/GE_fft_fixed.cpp` | missing | `microprocessor` | Implementation of the same canonical substrate FFT primitive. |
| `include/GE_fourier_fanout.hpp` | missing | `microprocessor` | Explicitly described as Fourier-transform fan-out microprocessor step. |
| `src/GE_fourier_fanout.cpp` | missing | `microprocessor` | Implements deterministic spectral-field stepping and derived probes. |
| `include/GE_frequency_transport.hpp` | missing | `microprocessor` | Single canonical frequency transport funnel enforcing causality bounds. |
| `include/GE_operator_registry.hpp` | missing | `microprocessor` | Canonical deterministic operator entrypoints for authoritative state evolution. |
| `src/GE_operator_registry.cpp` | missing | `microprocessor` | Implements authoritative state transition and commit path. |
| `include/GE_phase_current.hpp` | missing | `microprocessor` | Fixed-size current rail for deterministic phase-amplitude accumulation. |
| `src/GE_phase_current.cpp` | missing | `microprocessor` | Implements that canonical current rail. |
| `include/GE_pulse_trajectory_bound.hpp` | missing | `microprocessor` | Bounded deterministic pulse admission gate per anchor and tick. |
| `include/GE_safety_governor.hpp` | missing | `microprocessor` | Deterministic commit caps for materialized substrate work. |
| `include/GE_spectral_field_anchor.hpp` | missing | `microprocessor` | Authoritative spectral-field anchor contract. |
| `include/GE_state_signature.hpp` | missing | `microprocessor` | Deterministic reproducibility signature harness over authoritative state. |
| `src/GE_state_signature.cpp` | missing | `microprocessor` | Implements signature folding over canonical state. |
| `include/GE_temporal_summaries.hpp` | missing | `microprocessor` | Fixed-size authoritative measurement lanes for temporal coupling. |
| `include/GE_vector_budget.hpp` | missing | `microprocessor` | Deterministic vector-budget shaping by carrier authority codes. |
| `include/GE_voxel_coupling.hpp` | missing | `microprocessor` | Deterministic voxel-coupling step that updates substrate state and publishes packets. |
| `src/GE_voxel_coupling.cpp` | missing | `microprocessor` | Implements the voxel-coupling substrate step. |
| `include/GE_voxel_coupling_anchor.hpp` | missing | `microprocessor` | Authoritative voxel-coupling anchor contract. |
| `include/harmonic_signature.hpp` | missing | `microprocessor` | Deterministic per-anchor harmonic signature derived from anchor identity and coordinates. |
| `src/harmonic_signature.cpp` | missing | `microprocessor` | Implements the harmonic signature builder. |

Pass 18 surgical action:
- add only top-of-file canonical ingestion annotations to the files above
- update `docs/GENESIS_SUBSTRATE_ANNOTATION_SCHEMA.md` to record tranche 7 coverage and scope
- do not widen routing, parser behavior, or ingestion semantics
