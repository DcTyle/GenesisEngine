# Genesis Engine Substrate Annotation Schema

This file defines the canonical annotation contract for CPU-to-substrate ingestion.
It replaces fuzzy filename guessing with explicit top-of-file ownership.

Required keys for v1:
- `@substrate`
- `@artifact_class`
- `@ingest`
- `@canonical`

Supported substrate values in v1:
- `microprocessor`
- `ai_asset_vault`
- `coherence_observation`

Required rules:
- annotations must appear in the top-of-file comment region
- values are exact and case-insensitive only by ASCII fold
- missing required keys are malformed
- conflicting repeated keys are conflicting annotations
- unknown substrate names are rejected and reported
- `@ingest: true` and `@canonical: true` are required for actual ingestion
- `@canonical: deprecated` marks a deprecated candidate and preserves it without deletion

Optional keys accepted for future passes but ignored by v1 routing:
- `@operator_path`
- `@owner_region`
- `@export_class`
- `@language_family`
- `@derived_from`

Canonical runner behavior:
- scans only approved roots
- parses only top-of-file annotations
- does not infer ownership from filenames
- canonicalizes bytes via the existing strict UTF-8 canonicalization path
- derives deterministic vector IDs through the existing `EwId9`/`coord_sig9` path
- derives spectral/frequency artifacts through the existing symbol/spectral encoding path
- writes deterministic report categories:
  - `ingested`
  - `skipped`
  - `unannotated`
  - `malformed_annotation`
  - `conflicting_annotation`
  - `unknown_substrate`
  - `deprecated_candidate`

Migration tranches annotated so far:

First migration tranche:
- substrate microprocessor:
  - `include/substrate_alu.hpp`
  - `src/substrate_alu.cpp`
  - `include/substrate_harmonics.hpp`
  - `src/substrate_harmonics.cpp`
- AI asset vault:
  - `include/GE_ai_vault.hpp`
  - `src/GE_ai_vault.cpp`
- coherence observation:
  - `include/GE_coherence_graph_store.hpp`
  - `src/GE_coherence_graph_store.cpp`

Second migration tranche:
- substrate microprocessor:
  - `include/ew_substrate_manager.h`
  - `src/ew_substrate_manager.cpp`
  - `include/ew_substrate_microprocessor.h`
  - `src/ew_substrate_microprocessor.cpp`
- AI asset vault:
  - `include/GE_asset_substrate.hpp`
  - `src/GE_asset_substrate.cpp`
- coherence observation:
  - `include/GE_coherence_bus.hpp`
  - `src/GE_coherence_bus.cpp`
  - `include/coherence_graph.hpp`
  - `src/coherence_graph.cpp`
  - `include/GE_global_coherence.hpp`
  - `src/GE_global_coherence.cpp`

Notes:
- second tranche remains clear-owner only; ambiguous files are still intentionally left unannotated
- the `ew_substrate_microprocessor` header/implementation type mismatch was corrected while touching that tranche so the active canonical declaration matches the implementation

Third migration tranche:
- substrate microprocessor:
  - `include/GE_object_ancilla.hpp`
  - `src/GE_object_ancilla.cpp`
  - `include/GE_object_local_cuda.hpp`
  - `src/GE_object_local_cuda.cpp`
  - `include/GE_object_anchor.hpp`
- AI asset vault:
  - `include/GE_object_memory.hpp`
  - `src/GE_object_memory.cpp`
- coherence observation:
  - `include/GE_coherence_bus_anchor.hpp`
  - `include/GE_coherence_packets.hpp`

Notes:
- third tranche stays in the same clear-owner lane and focuses on object-memory/object-update/coherence-contract files that already sit directly on top of canonical annotated systems
- no fuzzy routing was added; only explicit top-of-file ownership markers were introduced for files whose substrate role was already materially obvious in the active inherited line

CLI entrypoint:
- `ge_substrate_ingest repo_root=. roots=include,src apply=false`
- `apply=true` writes per-substrate bundles under `GenesisEngineState/AnnotationIngest/`

The runner is intentionally non-destructive in v1. Deprecated candidates are reported, not deleted. Ambiguous files remain unannotated and are surfaced by the report instead of being force-routed by vibes, astrology, or filename perfume.

Fourth migration tranche:
- AI asset vault:
  - `include/GE_corpus_allowlist.hpp`
  - `src/GE_corpus_allowlist.cpp`
  - `include/GE_corpus_anchor_store.hpp`
  - `src/GE_corpus_anchor_store.cpp`
  - `include/GE_corpus_canonicalizer.hpp`
  - `src/GE_corpus_canonicalizer.cpp`
  - `include/GE_corpus_pulse_log.hpp`
  - `src/GE_corpus_pulse_log.cpp`
  - `include/GE_curriculum.hpp`
  - `include/GE_curriculum_manager.hpp`
  - `src/GE_curriculum_manager.cpp`
  - `include/GE_domain_policy.hpp`
  - `src/GE_domain_policy.cpp`
  - `include/GE_language_foundation.hpp`
  - `src/GE_language_foundation.cpp`

Notes:
- fourth tranche remains clear-owner only and stays entirely inside the canonical AI knowledge and policy lane already routed to `ai_asset_vault`
- no new substrate classes, parser rules, or ingestion behaviors were added in this tranche


Fifth migration tranche:
- AI asset vault:
  - `include/GE_audio_features.hpp`
  - `src/GE_audio_features.cpp`
  - `include/GE_audio_wav.hpp`
  - `src/GE_audio_wav.cpp`
  - `include/GE_g2p_english.hpp`
  - `src/GE_g2p_english.cpp`
  - `include/GE_g2p_lexicon.hpp`
  - `src/GE_g2p_lexicon.cpp`
  - `include/GE_forced_aligner.hpp`
  - `src/GE_forced_aligner.cpp`
  - `include/GE_speech_alignment.hpp`
  - `src/GE_speech_alignment.cpp`
  - `include/GE_voice_predictive_model.hpp`
  - `src/GE_voice_predictive_model.cpp`
  - `include/GE_voice_synth.hpp`
  - `src/GE_voice_synth.cpp`

Notes:
- fifth tranche remains intentionally narrow and stays entirely inside the deterministic speech/language lane already owned by `ai_asset_vault`
- this tranche adds no new routing behavior, parser rules, or substrate classes; it only makes explicit ownership visible for files whose role was already materially obvious in the active inherited line


Sixth migration tranche:
- AI asset vault:
  - `include/GE_ai_anticipation.hpp`
  - `src/GE_ai_anticipation.cpp`
  - `include/GE_ai_policy.hpp`
  - `src/GE_ai_policy.cpp`
  - `include/GE_neural_phase_ai.hpp`
  - `src/GE_neural_phase_ai.cpp`
  - `include/GE_learning_automation.hpp`
  - `src/GE_learning_automation.cpp`
  - `include/GE_learning_checkpoint_gate.hpp`
  - `src/GE_learning_checkpoint_gate.cpp`
  - `include/GE_live_crawler.hpp`
  - `src/GE_live_crawler.cpp`
  - `include/GE_repo_reader.hpp`
  - `src/GE_repo_reader.cpp`
  - `include/GE_rate_limiter.hpp`
  - `src/GE_rate_limiter.cpp`
  - `include/GE_quantity_peeling_trainer.hpp`
  - `src/GE_quantity_peeling_trainer.cpp`

Notes:
- sixth tranche remains bounded to the deterministic AI orchestration, acquisition, and curriculum-evaluation lane already owned by `ai_asset_vault`
- this tranche adds no new routing classes, parser behavior, or deletion workflow; it only marks clear-owner files that sit directly on top of already annotated corpus, curriculum, policy, and speech/crawl systems


Seventh migration tranche:
- substrate microprocessor:
  - `include/GE_budget_helpers.hpp`
  - `include/GE_causality_clamp.hpp`
  - `include/GE_fft_fixed.hpp`
  - `src/GE_fft_fixed.cpp`
  - `include/GE_fourier_fanout.hpp`
  - `src/GE_fourier_fanout.cpp`
  - `include/GE_frequency_transport.hpp`
  - `include/GE_operator_registry.hpp`
  - `src/GE_operator_registry.cpp`
  - `include/GE_phase_current.hpp`
  - `src/GE_phase_current.cpp`
  - `include/GE_pulse_trajectory_bound.hpp`
  - `include/GE_safety_governor.hpp`
  - `include/GE_spectral_field_anchor.hpp`
  - `include/GE_state_signature.hpp`
  - `src/GE_state_signature.cpp`
  - `include/GE_temporal_summaries.hpp`
  - `include/GE_vector_budget.hpp`
  - `include/GE_voxel_coupling.hpp`
  - `src/GE_voxel_coupling.cpp`
  - `include/GE_voxel_coupling_anchor.hpp`
  - `include/harmonic_signature.hpp`
  - `src/harmonic_signature.cpp`

Notes:
- seventh tranche stays inside the deterministic substrate operator/transport/signature lane already owned by `microprocessor`
- this tranche intentionally targets low-level carrier math, operator registry, spectral/voxel anchor contracts, and deterministic signature helpers whose ownership is materially explicit in the active inherited line
- no new routing values, parser rules, helper subsystems, or inference behavior were added in this tranche

Eighth migration tranche:
- substrate microprocessor:
  - `include/GE_collision_env.hpp`
  - `include/GE_collision_env_anchor.hpp`
  - `include/GE_collision_env_packets.hpp`
  - `include/GE_collision_constraint_packets.hpp`
  - `src/GE_collision_env.cpp`
  - `include/GE_planet_anchor.hpp`
  - `include/GE_planet_ancilla.hpp`
  - `src/GE_planet_ancilla.cpp`
  - `include/GE_nbody.hpp`
  - `src/GE_nbody.cpp`

Notes:
- eighth tranche remains bounded to the deterministic world-simulation lane already owned by `microprocessor`
- this tranche intentionally marks collision-environment packets, planet/runtime anchor evolution, and fixed-point N-body integration files whose substrate ownership is materially explicit in the active inherited line
- mesh baking, UV tooling, editor surfaces, and other mixed-lane files remain intentionally unannotated in this tranche
