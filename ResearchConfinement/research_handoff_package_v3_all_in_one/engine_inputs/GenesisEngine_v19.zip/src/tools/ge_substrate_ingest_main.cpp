#include <cstdio>
#include <string>
#include <vector>

#include "GE_substrate_annotation_ingest.hpp"
#include "ew_cli_args.hpp"

int main(int argc, char** argv) {
    ew::CliArgsKV cli;
    if (!ew::ew_cli_parse_kv_ascii(argc, argv, cli)) {
        std::fprintf(stderr, "ge_substrate_ingest: malformed args\n");
        return 2;
    }

    auto get_str_def = [&](const char* k, const char* defv)->std::string {
        std::string out;
        if (ew::ew_cli_get_str(cli, k, out)) return out;
        return std::string(defv ? defv : "");
    };
    auto get_bool_def = [&](const char* k, bool defv)->bool {
        bool out = defv;
        (void)ew::ew_cli_get_bool(cli, k, out);
        return out;
    };

    GE_SubstrateIngestOptions opt{};
    opt.repo_root_utf8 = get_str_def("repo_root", ".");
    opt.out_dir_utf8 = get_str_def("out_dir", "GenesisEngineState/AnnotationIngest");
    opt.apply_mode = get_bool_def("apply", false);
    const std::string roots_csv = get_str_def("roots", "include,src");
    {
        std::string cur;
        for (char ch : roots_csv) {
            if (ch == ',') {
                if (!cur.empty()) opt.approved_roots_utf8.push_back(cur);
                cur.clear();
            } else {
                cur.push_back(ch);
            }
        }
        if (!cur.empty()) opt.approved_roots_utf8.push_back(cur);
    }
    if (opt.approved_roots_utf8.empty()) {
        std::fprintf(stderr, "ge_substrate_ingest: roots must not be empty\n");
        return 2;
    }

    GE_SubstrateIngestReport report{};
    if (!GE_run_substrate_annotation_ingest(opt, report)) {
        std::fprintf(stderr, "ge_substrate_ingest: ingest runner failed\n");
        return 3;
    }
    if (!GE_write_substrate_ingest_report(opt.out_dir_utf8, report)) {
        std::fprintf(stderr, "ge_substrate_ingest: failed to write report\n");
        return 3;
    }

    std::printf("GE_SUBSTRATE_INGEST:mode=%s ingested=%u skipped=%u unannotated=%u malformed_annotation=%u conflicting_annotation=%u unknown_substrate=%u deprecated_candidate=%u bytes_in=%llu bytes_out=%llu rejects_utf8=%llu\n",
                opt.apply_mode ? "apply" : "dry_run",
                report.ingested_count_u32,
                report.skipped_count_u32,
                report.unannotated_count_u32,
                report.malformed_count_u32,
                report.conflicting_count_u32,
                report.unknown_substrate_count_u32,
                report.deprecated_count_u32,
                (unsigned long long)report.canonicalize_stats.bytes_in_u64,
                (unsigned long long)report.canonicalize_stats.bytes_out_u64,
                (unsigned long long)report.canonicalize_stats.invalid_utf8_rejects_u64);
    return 0;
}
