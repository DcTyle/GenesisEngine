#include "GE_substrate_annotation_ingest.hpp"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <map>
#include <sstream>
#include <vector>

#include "GE_temporal_summaries.hpp"
#include "bytes_encoder.hpp"
#include "crawler_encode_cuda.hpp"
#include "ew_id9.hpp"
#include "frequency_collapse.hpp"

namespace {

static inline std::string ge_trim_ascii(const std::string& s) {
    size_t b = 0;
    while (b < s.size() && std::isspace((unsigned char)s[b])) ++b;
    size_t e = s.size();
    while (e > b && std::isspace((unsigned char)s[e - 1])) --e;
    return s.substr(b, e - b);
}

static inline void ge_ascii_lower_inplace(std::string& s) {
    for (char& ch : s) {
        unsigned char c = (unsigned char)ch;
        if (c >= 'A' && c <= 'Z') ch = char(c - 'A' + 'a');
    }
}

static inline std::string ge_normalize_annotation_text(std::string s) {
    s = ge_trim_ascii(s);
    if (s.rfind("//", 0) == 0) s = ge_trim_ascii(s.substr(2));
    else if (s.rfind("#", 0) == 0) s = ge_trim_ascii(s.substr(1));
    else if (s.rfind("/*", 0) == 0) s = ge_trim_ascii(s.substr(2));
    else if (s.rfind("*", 0) == 0) s = ge_trim_ascii(s.substr(1));
    if (!s.empty() && s.size() >= 2 && s.compare(s.size() - 2, 2, "*/") == 0) {
        s = ge_trim_ascii(s.substr(0, s.size() - 2));
    }
    return s;
}

static inline bool ge_read_file_bytes(const std::string& path_utf8, std::vector<uint8_t>& out) {
    std::ifstream is(path_utf8, std::ios::binary);
    if (!is) return false;
    is.seekg(0, std::ios::end);
    const std::streamoff n = is.tellg();
    if (n < 0) return false;
    is.seekg(0, std::ios::beg);
    out.resize((size_t)n);
    if (n > 0) {
        if (!is.read(reinterpret_cast<char*>(out.data()), n)) return false;
    }
    return true;
}

static inline bool ge_write_blob_append(std::ofstream& blob, const std::string& s, uint64_t& out_off) {
    out_off = uint64_t(blob.tellp());
    if (!blob) return false;
    blob.write(s.data(), std::streamsize(s.size()));
    const char nl = '\n';
    blob.write(&nl, 1);
    return bool(blob);
}

static inline std::string ge_path_to_utf8(const std::filesystem::path& p) {
    auto u8 = p.generic_u8string();
    return std::string(reinterpret_cast<const char*>(u8.data()), u8.size());
}

static inline std::string ge_category_ascii(GE_SubstrateIngestCategory c) {
    switch (c) {
        case GE_SubstrateIngestCategory::Ingested: return "ingested";
        case GE_SubstrateIngestCategory::Skipped: return "skipped";
        case GE_SubstrateIngestCategory::Unannotated: return "unannotated";
        case GE_SubstrateIngestCategory::MalformedAnnotation: return "malformed_annotation";
        case GE_SubstrateIngestCategory::ConflictingAnnotation: return "conflicting_annotation";
        case GE_SubstrateIngestCategory::UnknownSubstrate: return "unknown_substrate";
        case GE_SubstrateIngestCategory::DeprecatedCandidate: return "deprecated_candidate";
    }
    return "skipped";
}

static inline void ge_increment_category(GE_SubstrateIngestReport& r, GE_SubstrateIngestCategory c) {
    switch (c) {
        case GE_SubstrateIngestCategory::Ingested: ++r.ingested_count_u32; break;
        case GE_SubstrateIngestCategory::Skipped: ++r.skipped_count_u32; break;
        case GE_SubstrateIngestCategory::Unannotated: ++r.unannotated_count_u32; break;
        case GE_SubstrateIngestCategory::MalformedAnnotation: ++r.malformed_count_u32; break;
        case GE_SubstrateIngestCategory::ConflictingAnnotation: ++r.conflicting_count_u32; break;
        case GE_SubstrateIngestCategory::UnknownSubstrate: ++r.unknown_substrate_count_u32; break;
        case GE_SubstrateIngestCategory::DeprecatedCandidate: ++r.deprecated_count_u32; break;
    }
}

static inline bool ge_parse_bool_strict(const std::string& s, bool* out) {
    std::string t = s;
    ge_ascii_lower_inplace(t);
    if (t == "true") { *out = true; return true; }
    if (t == "false") { *out = false; return true; }
    return false;
}

static inline bool ge_is_known_annotation_key(const std::string& key) {
    return key == "@substrate" || key == "@artifact_class" || key == "@ingest" || key == "@canonical" ||
           key == "@operator_path" || key == "@owner_region" || key == "@export_class" ||
           key == "@language_family" || key == "@derived_from";
}

static inline bool ge_parse_annotation_line(const std::string& line, std::string& out_key, std::string& out_value) {
    const size_t colon = line.find(':');
    if (colon == std::string::npos) return false;
    out_key = ge_trim_ascii(line.substr(0, colon));
    out_value = ge_trim_ascii(line.substr(colon + 1));
    ge_ascii_lower_inplace(out_key);
    return !out_key.empty();
}

static inline bool ge_line_looks_like_comment_or_blank(const std::string& raw) {
    std::string s = ge_trim_ascii(raw);
    if (s.empty()) return true;
    return s.rfind("//", 0) == 0 || s.rfind("#", 0) == 0 || s.rfind("/*", 0) == 0 || s.rfind("*", 0) == 0 || s.rfind("*/", 0) == 0;
}

static inline bool ge_relpath_under_root(const std::string& rel_utf8, const std::vector<std::string>& roots) {
    for (const std::string& root : roots) {
        if (rel_utf8 == root) return true;
        if (rel_utf8.size() > root.size() && rel_utf8.compare(0, root.size(), root) == 0 && rel_utf8[root.size()] == '/') return true;
    }
    return false;
}

} // namespace

bool GE_parse_top_of_file_substrate_annotation(const std::string& text_utf8,
                                               GE_SubstrateAnnotation& out) {
    out = GE_SubstrateAnnotation{};
    std::istringstream iss(text_utf8);
    std::string line;
    uint32_t line_no = 0;
    bool saw_any_annotation = false;
    while (std::getline(iss, line) && line_no < 64u) {
        ++line_no;
        const std::string norm = ge_normalize_annotation_text(line);
        if (norm.empty()) {
            if (saw_any_annotation) break;
            continue;
        }
        if (!ge_line_looks_like_comment_or_blank(line)) {
            break;
        }
        if (norm.empty() || norm[0] != '@') {
            if (saw_any_annotation) continue;
            continue;
        }
        std::string key;
        std::string value;
        if (!ge_parse_annotation_line(norm, key, value)) {
            out.malformed = true;
            out.issue_utf8 = "annotation_line_missing_colon";
            return false;
        }
        if (!ge_is_known_annotation_key(key)) {
            out.malformed = true;
            out.issue_utf8 = std::string("unknown_annotation_key:") + key;
            return false;
        }
        saw_any_annotation = true;
        if (key == "@substrate") {
            if (out.has_substrate && out.substrate_utf8 != value) {
                out.conflicting = true;
                out.issue_utf8 = "conflicting_@substrate";
                return false;
            }
            out.substrate_utf8 = value;
            ge_ascii_lower_inplace(out.substrate_utf8);
            out.has_substrate = true;
        } else if (key == "@artifact_class") {
            if (out.has_artifact_class && out.artifact_class_utf8 != value) {
                out.conflicting = true;
                out.issue_utf8 = "conflicting_@artifact_class";
                return false;
            }
            out.artifact_class_utf8 = value;
            ge_ascii_lower_inplace(out.artifact_class_utf8);
            out.has_artifact_class = true;
        } else if (key == "@ingest") {
            bool v = false;
            if (!ge_parse_bool_strict(value, &v)) {
                out.malformed = true;
                out.issue_utf8 = "malformed_@ingest";
                return false;
            }
            if (out.has_ingest && out.ingest_enabled != v) {
                out.conflicting = true;
                out.issue_utf8 = "conflicting_@ingest";
                return false;
            }
            out.ingest_enabled = v;
            out.has_ingest = true;
        } else if (key == "@canonical") {
            std::string v = value;
            ge_ascii_lower_inplace(v);
            GE_SubstrateAnnotation::CanonicalState st = GE_SubstrateAnnotation::CanonicalState::FalseState;
            if (v == "true") st = GE_SubstrateAnnotation::CanonicalState::TrueState;
            else if (v == "false") st = GE_SubstrateAnnotation::CanonicalState::FalseState;
            else if (v == "deprecated") st = GE_SubstrateAnnotation::CanonicalState::Deprecated;
            else {
                out.malformed = true;
                out.issue_utf8 = "malformed_@canonical";
                return false;
            }
            if (out.has_canonical && out.canonical_state != st) {
                out.conflicting = true;
                out.issue_utf8 = "conflicting_@canonical";
                return false;
            }
            out.canonical_state = st;
            out.has_canonical = true;
        }
    }

    if (!saw_any_annotation) return false;
    if (!out.has_substrate || !out.has_artifact_class || !out.has_ingest || !out.has_canonical) {
        out.malformed = true;
        out.issue_utf8 = "missing_required_annotation";
        return false;
    }
    return true;
}

const GE_SubstrateRoute* GE_find_substrate_route_ascii(const std::string& substrate_utf8) {
    static const GE_SubstrateRoute kRoutes[] = {
        {"microprocessor", 0u, ew_id9_from_string_ascii("substrate:microprocessor")},
        {"ai_asset_vault", 1u, ew_id9_from_string_ascii("substrate:ai_asset_vault")},
        {"coherence_observation", 2u, ew_id9_from_string_ascii("substrate:coherence_observation")},
    };
    for (const GE_SubstrateRoute& r : kRoutes) {
        if (substrate_utf8 == r.substrate_ascii) return &r;
    }
    return nullptr;
}

bool GE_run_substrate_annotation_ingest(const GE_SubstrateIngestOptions& opt,
                                        GE_SubstrateIngestReport& out_report) {
    out_report = GE_SubstrateIngestReport{};
    namespace fs = std::filesystem;
    const fs::path repo_root = fs::path(opt.repo_root_utf8);
    const fs::path out_dir = fs::path(opt.out_dir_utf8);

    std::vector<fs::path> files;
    for (auto it = fs::recursive_directory_iterator(repo_root); it != fs::recursive_directory_iterator(); ++it) {
        if (!it->is_regular_file()) continue;
        const std::string rel = ge_path_to_utf8(fs::relative(it->path(), repo_root));
        if (!ge_relpath_under_root(rel, opt.approved_roots_utf8)) continue;
        files.push_back(it->path());
    }
    std::sort(files.begin(), files.end(), [](const fs::path& a, const fs::path& b) {
        return a.generic_u8string() < b.generic_u8string();
    });

    std::map<std::string, GE_SubstrateIngestArtifactBundle> bundles;
    std::map<std::string, std::ofstream> blob_streams;

    if (opt.apply_mode) {
        fs::create_directories(out_dir);
    }

    for (const fs::path& fp : files) {
        const std::string rel = ge_path_to_utf8(fs::relative(fp, repo_root));
        std::vector<uint8_t> raw_bytes;
        GE_SubstrateIngestRecord rec{};
        rec.relpath_utf8 = rel;
        rec.source_id9 = ew_id9_from_string_ascii(rel);
        if (!ge_read_file_bytes(fp.string(), raw_bytes)) {
            rec.category = GE_SubstrateIngestCategory::Skipped;
            rec.note_utf8 = "read_failed";
            ge_increment_category(out_report, rec.category);
            out_report.records.push_back(rec);
            continue;
        }
        const std::string text_utf8(reinterpret_cast<const char*>(raw_bytes.data()), raw_bytes.size());
        GE_SubstrateAnnotation ann{};
        const bool parsed = GE_parse_top_of_file_substrate_annotation(text_utf8, ann);
        if (!parsed) {
            if (ann.conflicting) {
                rec.category = GE_SubstrateIngestCategory::ConflictingAnnotation;
                rec.note_utf8 = ann.issue_utf8;
            } else if (ann.malformed) {
                rec.category = GE_SubstrateIngestCategory::MalformedAnnotation;
                rec.note_utf8 = ann.issue_utf8;
            } else {
                rec.category = GE_SubstrateIngestCategory::Unannotated;
                rec.note_utf8 = "missing_top_of_file_annotations";
            }
            ge_increment_category(out_report, rec.category);
            out_report.records.push_back(rec);
            continue;
        }
        rec.substrate_utf8 = ann.substrate_utf8;
        rec.artifact_class_utf8 = ann.artifact_class_utf8;

        if (ann.canonical_state == GE_SubstrateAnnotation::CanonicalState::Deprecated) {
            rec.category = GE_SubstrateIngestCategory::DeprecatedCandidate;
            rec.note_utf8 = "deprecated_candidate_preserved_no_delete";
            ge_increment_category(out_report, rec.category);
            out_report.records.push_back(rec);
            continue;
        }

        const GE_SubstrateRoute* route = GE_find_substrate_route_ascii(ann.substrate_utf8);
        if (!route) {
            rec.category = GE_SubstrateIngestCategory::UnknownSubstrate;
            rec.note_utf8 = "unknown_substrate_route";
            ge_increment_category(out_report, rec.category);
            out_report.records.push_back(rec);
            continue;
        }
        rec.lane_u8 = route->lane_u8;

        if (!ann.ingest_enabled || ann.canonical_state != GE_SubstrateAnnotation::CanonicalState::TrueState) {
            rec.category = GE_SubstrateIngestCategory::Skipped;
            rec.note_utf8 = "annotation_requests_skip";
            ge_increment_category(out_report, rec.category);
            out_report.records.push_back(rec);
            continue;
        }

        std::string canon_utf8;
        if (!GE_canonicalize_utf8_strict(raw_bytes.data(), raw_bytes.size(), canon_utf8, out_report.canonicalize_stats)) {
            rec.category = GE_SubstrateIngestCategory::Skipped;
            rec.note_utf8 = "canonicalize_failed";
            ge_increment_category(out_report, rec.category);
            out_report.records.push_back(rec);
            continue;
        }
        rec.canonical_bytes_u32 = (uint32_t)canon_utf8.size();
        rec.frequency_code_s32 = ew_bytes_to_frequency_code(reinterpret_cast<const uint8_t*>(canon_utf8.data()), canon_utf8.size(), 0u);
        rec.artifact_id9 = coord_sig9(route->domain_id9,
                                      reinterpret_cast<const uint8_t*>(canon_utf8.data()),
                                      canon_utf8.size());

        if (opt.apply_mode) {
            SpiderCode4 sc{};
            if (!ew_encode_spidercode4_from_bytes_chunked_cuda(reinterpret_cast<const uint8_t*>(canon_utf8.data()), canon_utf8.size(), 4096u, &sc)) {
                rec.category = GE_SubstrateIngestCategory::Skipped;
                rec.note_utf8 = "spidercode4_encode_failed";
                ge_increment_category(out_report, rec.category);
                out_report.records.push_back(rec);
                continue;
            }
            std::vector<EwFreqComponentQ32_32> comps;
            comps.reserve(4u);
            auto push_comp = [&](int32_t f_code, int32_t a_code, int32_t phi_code) {
                EwFreqComponentQ32_32 c{};
                c.f_turns_q32_32 = int64_t(f_code) << 16;
                c.a_q32_32 = int64_t(a_code) << 16;
                c.phi_turns_q32_32 = int64_t(phi_code) << 16;
                comps.push_back(c);
            };
            push_comp(sc.f_code, sc.a_code, sc.v_code);
            push_comp(sc.a_code, sc.v_code, sc.i_code);
            push_comp(sc.v_code, sc.i_code, sc.f_code);
            push_comp(sc.i_code, sc.f_code, sc.a_code);
            EwCarrierParams carrier{};
            if (!ew_collapse_frequency_components_q32_32(comps, carrier)) {
                rec.category = GE_SubstrateIngestCategory::Skipped;
                rec.note_utf8 = "carrier_collapse_failed";
                ge_increment_category(out_report, rec.category);
                out_report.records.push_back(rec);
                continue;
            }

            GE_SubstrateIngestArtifactBundle& bundle = bundles[ann.substrate_utf8];
            if (bundle.substrate_utf8.empty()) bundle.substrate_utf8 = ann.substrate_utf8;
            fs::path substrate_dir = out_dir / ann.substrate_utf8;
            fs::create_directories(substrate_dir);
            std::ofstream& blob = blob_streams[ann.substrate_utf8];
            if (!blob.is_open()) {
                blob.open((substrate_dir / "blobs.txt").string(), std::ios::binary | std::ios::app);
            }
            if (!blob) {
                rec.category = GE_SubstrateIngestCategory::Skipped;
                rec.note_utf8 = "blob_open_failed";
                ge_increment_category(out_report, rec.category);
                out_report.records.push_back(rec);
                continue;
            }
            uint64_t blob_off = 0;
            if (!ge_write_blob_append(blob, canon_utf8, blob_off)) {
                rec.category = GE_SubstrateIngestCategory::Skipped;
                rec.note_utf8 = "blob_write_failed";
                ge_increment_category(out_report, rec.category);
                out_report.records.push_back(rec);
                continue;
            }

            GE_CorpusAnchorRecord ar{};
            ar.lane_u8 = route->lane_u8;
            ar.domain_id9 = route->domain_id9;
            ar.source_id9 = rec.source_id9;
            ar.seq_u32 = bundle.next_seq_u32;
            ar.offset_u32 = 0u;
            ar.size_u32 = (uint32_t)canon_utf8.size();
            ar.sc4 = sc;
            ar.carrier = carrier;
            ar.anchor_id9 = GE_anchor_id9_from_provenance_and_carrier(ar.lane_u8, ar.domain_id9, ar.source_id9, ar.seq_u32, ar.offset_u32, ar.carrier);
            ar.payload_relpath_utf8 = "blobs.txt";
            ar.payload_byte_off_u64 = blob_off;
            bundle.anchor_store.records.push_back(ar);

            GE_CorpusPulseRecord pr{};
            pr.lane_u8 = ar.lane_u8;
            pr.domain_id9 = ar.domain_id9;
            pr.source_id9 = ar.source_id9;
            pr.seq_u32 = ar.seq_u32;
            pr.offset_u32 = ar.offset_u32;
            pr.size_u32 = ar.size_u32;
            pr.sc4 = ar.sc4;
            pr.carrier = ar.carrier;
            pr.payload_relpath_utf8 = ar.payload_relpath_utf8;
            pr.payload_byte_off_u64 = ar.payload_byte_off_u64;
            bundle.pulse_log.records.push_back(pr);
            rec.seq_u32 = bundle.next_seq_u32;
            ++bundle.next_seq_u32;
        }

        rec.category = GE_SubstrateIngestCategory::Ingested;
        rec.note_utf8 = opt.apply_mode ? "ingested_via_canonical_symbol_spectral_path" : "dry_run_ready";
        ge_increment_category(out_report, rec.category);
        out_report.records.push_back(rec);
    }

    if (opt.apply_mode) {
        for (auto& kv : blob_streams) kv.second.flush();
        for (auto& kv : bundles) {
            kv.second.anchor_store.sort_and_dedupe();
            kv.second.pulse_log.sort_stable();
            const fs::path substrate_dir = out_dir / kv.first;
            if (!kv.second.anchor_store.save_to_file((substrate_dir / "anchors.gecas").string())) return false;
            if (!kv.second.pulse_log.save_to_file((substrate_dir / "pulses.gepl").string())) return false;
        }
    }

    std::sort(out_report.records.begin(), out_report.records.end(), [](const GE_SubstrateIngestRecord& a, const GE_SubstrateIngestRecord& b) {
        return a.relpath_utf8 < b.relpath_utf8;
    });
    return true;
}

bool GE_write_substrate_ingest_report(const std::string& out_dir_utf8,
                                      const GE_SubstrateIngestReport& report) {
    namespace fs = std::filesystem;
    fs::create_directories(fs::path(out_dir_utf8));
    {
        std::ofstream os((fs::path(out_dir_utf8) / "annotation_ingest_report.tsv").string(), std::ios::binary);
        if (!os) return false;
        os << "category\trelpath\tsubstrate\tartifact_class\tlane\tseq\tcanonical_bytes\tfrequency_code\tnote\n";
        for (const auto& r : report.records) {
            os << ge_category_ascii(r.category) << '\t'
               << r.relpath_utf8 << '\t'
               << r.substrate_utf8 << '\t'
               << r.artifact_class_utf8 << '\t'
               << (unsigned)r.lane_u8 << '\t'
               << r.seq_u32 << '\t'
               << r.canonical_bytes_u32 << '\t'
               << r.frequency_code_s32 << '\t'
               << r.note_utf8 << '\n';
        }
    }
    {
        std::ofstream os((fs::path(out_dir_utf8) / "annotation_ingest_summary.txt").string(), std::ios::binary);
        if (!os) return false;
        os << "ANNOTATION_INGEST summary\n";
        os << "ingested=" << report.ingested_count_u32 << "\n";
        os << "skipped=" << report.skipped_count_u32 << "\n";
        os << "unannotated=" << report.unannotated_count_u32 << "\n";
        os << "malformed_annotation=" << report.malformed_count_u32 << "\n";
        os << "conflicting_annotation=" << report.conflicting_count_u32 << "\n";
        os << "unknown_substrate=" << report.unknown_substrate_count_u32 << "\n";
        os << "deprecated_candidate=" << report.deprecated_count_u32 << "\n";
        os << "bytes_in=" << report.canonicalize_stats.bytes_in_u64 << "\n";
        os << "bytes_out=" << report.canonicalize_stats.bytes_out_u64 << "\n";
        os << "invalid_utf8_rejects=" << report.canonicalize_stats.invalid_utf8_rejects_u64 << "\n";
    }
    return true;
}
