# PASS 17 Implementation Matrix

Pass focus: Additional later series J — annotation-driven CPU-to-substrate ingestion, bounded tranche 6 only.

Classification for this pass:
- `include/GE_ai_anticipation.hpp` — partial; clear-owner deterministic AI routing surface not yet annotated
- `src/GE_ai_anticipation.cpp` — partial; canonical implementation of the same routing surface not yet annotated
- `include/GE_ai_policy.hpp` — partial; clear-owner AI policy surface not yet annotated
- `src/GE_ai_policy.cpp` — partial; canonical implementation of the same policy surface not yet annotated
- `include/GE_neural_phase_ai.hpp` — partial; clear-owner internal AI control surface not yet annotated
- `src/GE_neural_phase_ai.cpp` — partial; canonical implementation of the same control surface not yet annotated
- `include/GE_learning_automation.hpp` — partial; deterministic automation/curriculum orchestration surface not yet annotated
- `src/GE_learning_automation.cpp` — partial; canonical implementation of the same automation surface not yet annotated
- `include/GE_learning_checkpoint_gate.hpp` — partial; clear-owner learning checkpoint gate not yet annotated
- `src/GE_learning_checkpoint_gate.cpp` — partial; canonical implementation of the same gate not yet annotated
- `include/GE_live_crawler.hpp` — partial; deterministic acquisition surface already bounded by policy/rate-limit systems but not yet annotated
- `src/GE_live_crawler.cpp` — partial; canonical implementation of the same acquisition surface not yet annotated
- `include/GE_repo_reader.hpp` — partial; deterministic self-repo observation surface not yet annotated
- `src/GE_repo_reader.cpp` — partial; canonical implementation of the same repo observation surface not yet annotated
- `include/GE_rate_limiter.hpp` — partial; crawler-policy support surface with clear ownership in the AI acquisition lane not yet annotated
- `src/GE_rate_limiter.cpp` — partial; canonical implementation of the same rate-limit surface not yet annotated
- `include/GE_quantity_peeling_trainer.hpp` — partial; deterministic curriculum/training surface not yet annotated
- `src/GE_quantity_peeling_trainer.cpp` — partial; canonical implementation of the same trainer surface not yet annotated
- `docs/GENESIS_SUBSTRATE_ANNOTATION_SCHEMA.md` — partial; needs tranche-6 coverage recorded

Implementation action for Pass 17:
- add strict top-of-file annotations only
- keep routing constrained to `ai_asset_vault`
- update schema documentation to record tranche 6 scope and rationale
- do not touch ambiguous crawler/encoding substrate files in this pass
