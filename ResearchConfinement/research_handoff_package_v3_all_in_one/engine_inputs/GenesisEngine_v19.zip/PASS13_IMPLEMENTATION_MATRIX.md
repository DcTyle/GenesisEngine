# PASS 13 IMPLEMENTATION MATRIX — Annotation-driven CPU-to-substrate ingestion (J-series tranche 2)

## Scope
This pass continues the dedicated J-series using the existing canonical annotation-driven ingestion pipeline. It does **not** create new substrate classes, synonym routes, or a second migration path. It extends only the clear-owner annotation tranche, updates the canonical schema doc to reflect the widened tranche, and fixes one active declaration mismatch discovered while validating a touched annotated file.

## File-by-file matrix

| File | Status | Role in Pass 13 |
|---|---|---|
| `include/ew_substrate_manager.h` | Updated | Second-tranche clear-owner annotation: `microprocessor` boot surface |
| `src/ew_substrate_manager.cpp` | Updated | Second-tranche clear-owner annotation: `microprocessor` boot surface |
| `include/ew_substrate_microprocessor.h` | Updated | Second-tranche clear-owner annotation and canonical declaration fix to match implementation return type |
| `src/ew_substrate_microprocessor.cpp` | Updated | Second-tranche clear-owner annotation: `microprocessor` boot surface |
| `include/GE_asset_substrate.hpp` | Updated | Second-tranche clear-owner annotation: `ai_asset_vault` asset substrate/library surface |
| `src/GE_asset_substrate.cpp` | Updated | Second-tranche clear-owner annotation: `ai_asset_vault` asset substrate/library surface |
| `include/GE_coherence_bus.hpp` | Updated | Second-tranche clear-owner annotation: `coherence_observation` bus/operator surface |
| `src/GE_coherence_bus.cpp` | Updated | Second-tranche clear-owner annotation: `coherence_observation` bus/operator surface |
| `include/coherence_graph.hpp` | Updated | Second-tranche clear-owner annotation: `coherence_observation` graph/index surface |
| `src/coherence_graph.cpp` | Updated | Second-tranche clear-owner annotation: `coherence_observation` graph/index surface |
| `include/GE_global_coherence.hpp` | Updated | Second-tranche clear-owner annotation: `coherence_observation` accumulator surface |
| `src/GE_global_coherence.cpp` | Updated | Second-tranche clear-owner annotation: `coherence_observation` accumulator surface |
| `docs/GENESIS_SUBSTRATE_ANNOTATION_SCHEMA.md` | Updated | Documents tranche 2 coverage and records the validation-driven declaration fix |

## Contract closure in this pass

- **J5 continuing clear-owner migration only**: extended the annotation set only for files with direct and stable substrate ownership.
- **No J3 synonym explosion**: substrate values remain only `microprocessor`, `ai_asset_vault`, and `coherence_observation`.
- **No parallel migration system**: all new tranche coverage still flows through the existing canonical parser/runner/report path from Pass 12.
- **Validation-driven cleanup on touched path**: corrected the active `ew_substrate_microprocessor` header declaration so the canonical declaration matches the implementation and existing callsites.

## Validation

The following syntax checks were run successfully:

- `g++ -std=c++17 -fsyntax-only -Iinclude src/ew_substrate_manager.cpp`
- `g++ -std=c++17 -fsyntax-only -Iinclude src/ew_substrate_microprocessor.cpp`
- `g++ -std=c++17 -fsyntax-only -Iinclude src/GE_asset_substrate.cpp`
- `g++ -std=c++17 -fsyntax-only -Iinclude src/GE_coherence_bus.cpp`
- `g++ -std=c++17 -fsyntax-only -Iinclude src/coherence_graph.cpp`
- `g++ -std=c++17 -fsyntax-only -Iinclude src/GE_global_coherence.cpp`
